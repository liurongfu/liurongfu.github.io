$proto.bgsound='';
$proto.header={
	correct_offset_right:5,
	bg:'#162836',
	lg:{
		h:57
	},
	xs:{
		show:true,
		h:57
	}
};
$proto.actions={
	'p01-1':{
		load:function (){

		},leave:function (nextIndex, direction){

		}
	}
};
