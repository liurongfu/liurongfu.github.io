
function convertFormattedTime(fs){
   var a1=fs.indexOf(":");
   var a2=fs.lastIndexOf(":");
   var a3=fs.length;
   var strHH=parseFloat(fs.substring(0,a1))*3600;
   var strMM=parseFloat(fs.substring(a1+1,a2))*60;
   var strSS=parseFloat(fs.substring(a2+1,a3));
   return strHH+strMM+strSS;
}
function convertTotalSeconds(ts){
   var sec=(ts%60);
   ts-=sec;
   var tmp=(ts%3600);
   ts-=tmp;
   sec=Math.round(sec*100)/100;
   var strSec=new String(sec);
   var strWholeSec=strSec;
   var strFractionSec="";
   if(strSec.indexOf(".")!=-1){
	  strWholeSec= strSec.substring(0,strSec.indexOf("."));
	  strFractionSec=strSec.substring(strSec.indexOf(".")+1,strSec.length);
   }
   if(strWholeSec.length<2){
	  strWholeSec="0"+strWholeSec;
   }
   strSec=strWholeSec;
   if(strFractionSec.length){
	  strSec=strSec+"."+strFractionSec;
   }
   if((ts%3600)!=0){var hour=0;}else{var hour=(ts/3600);}
   if((tmp%60)!=0){var min=0;}else{var min=(tmp/60);}

   if((new String(hour)).length<2){hour="0"+hour;}
   if((new String(min)).length<2){min="0"+min;}
   var rtnVal=hour+":"+min+":"+strSec;
   return rtnVal;
}
