(function() {
  var method;
  var noop = function() {};
  var methods = [
      'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
      'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
      'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
      'timeStamp', 'trace', 'warn'
  ];
  var length = methods.length;
  var console = (window.console = window.console || {});

  while (length--) {
    method = methods[length];

    // Only stub undefined methods.
    if (!console[method]) {
      console[method] = noop;
    }
  }
}());
function doTap(eo,fn){
    if(!device.desktop()){
        //eo.tap(fn);
        eo.unbind().bind('click',fn);
    }else{
        eo.unbind().bind('click',fn);
    }
}
function doAniMS(a,fn){
	//并行
	var t=0;
	for(var i=0;i<a.length;i++){
		var b=a[i];
		if(b.t>t){t=b.t;}
		(function (){
			var _i=i;
			var _b=b;
			doAni(_b.d,_b.x,_b.t);
		})();
	}
	(function (){
		var _fn=fn;
		setTimeout(function (){
			_fn();
		},t+2500);
	})();
}
function doAniM(a,fn){
	//顺序
	if(km_cmdlist['ani']){
		km_cmdlist['ani']=null;
		try{delete km_cmdlist['ani'];}catch(e){}
	}
	km_cmdlist['ani']=new km_cl('ani');
	for(var i=0;i<a.length;i++){
		(function (){
			var _i=i;
			var b=a[_i];
			km_cmdlist['ani'].cmdA.push({func:function (){
				doAni(b.d,b.x,null,function (){
					try{km_cmdlist['ani'].doCmdA();}catch(e){}
				});
			}});
		})();
	}
	(function (){
		var _fn=fn;
		km_cmdlist['ani'].cmdA.push({func:function (){
			if(typeof _fn=='function' || typeof _fn=='object'){
				_fn();
			}
			try{km_cmdlist['ani'].doCmdA();}catch(e){}
		}});
	})();
	km_cmdlist['ani'].cmdA.push({func:function (){
		km_cmdlist['ani']=null;
		try{delete km_cmdlist['ani'];}catch(e){}
	}});
	km_cmdlist['ani'].cmdI=0;
	km_cmdlist['ani'].doCmdA();
}
function doAni(d,x,t,fn){
	(function (){
		var _fn=fn;
		$(d).css({visibility:'visible'});
		if(t!==undefined && t!==null){
			$(d).css({
				'-webkit-animation-delay':t+'ms',
				'animation-delay':t+'ms'
			});
		}
		$(d).addClass(x + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass(x + ' animated');
	    if(typeof _fn=='function' || typeof _fn=='object'){
				_fn();
		  }
	  });
	})();
}
function km_vplay(idx){
	videoAdapter.dispose();
	var vw=hvideo[idx].w;
	var vh=hvideo[idx].h;

	$(hvideo[idx].selector+' .video-box').css({
		'width':vw+'px',
		'height':vh+'px',
		'top':'50%',
		'left':'50%',
		'margin-left':(0-vw/2)+'px',
		'margin-top':(0-vh/2)+'px'
	});
	videoAdapter.init(
		hvideo[idx].selector
		,hvideo[idx].vid
		,{
			width:vw
			,height:vh
			,controls:false
			,autoplay:true
			,preload:"auto"
			,poster:"img/transparent.png"
			,loop:false
		}
		,function (){

		}
	);
	//videoAdapter.doend=function (){};
	//videoAdapter.addSioEvent('ended');
	videoAdapter.msrc(hvideo[idx].src);
}
var km_jc={
	currloadorder:1
	,pageresourceload:{}
	,pageresourcerender:{}
	,loadresource:function (fn){
		km_cmdlist['res']=new km_cl('res');
		for(var k in $proto.pages){
			if($proto.pages[k]['loadorder']!=km_jc.currloadorder){continue;}
			(function (){
				var _k=k;
				km_cmdlist['res'].cmdA.push({func:function (){
					km_jc.loadresource_i(_k,function (){
						km_cmdlist['res'].doCmdA();
					});
				}});
			})();
		}
		(function (){
			var _fn=fn;
			km_cmdlist['res'].cmdA.push({func:function (){
				km_jc.currloadorder++;
				_fn();
				try{
					km_cmdlist['res']=null;
					delete km_cmdlist['res'];
				}catch(e){}
			}});
		})();
		km_cmdlist['res'].cmdI=0;
		km_cmdlist['res'].doCmdA();
	}
	,loadresource_i:function (pid,fn){
		km_jc.fn=(typeof fn=='undefined')?function (){}:fn;
		if(km_jc.pageresourceload[pid]){
			km_jc.fn();
			return;
		}
		var imgO=new km_image();
		imgO.himgs={};
		(function (){
			var _pid=pid;
			imgO.func=function (){}
			imgO.after=function (){
				$proto.pages[_pid].size=imgO.size[_pid];
				if(typeof $proto.pages[_pid]['elems']!='undefined'){
					for(var j in $proto.pages[_pid]['elems']){
						if($proto.pages[_pid]['elems'][j]['type']=='text'){continue;}
						$proto.pages[_pid]['elems'][j].size=imgO.size[j];
					}
				}
				km_jc.pageresourceload[_pid]=true;
				km_jc.fn();
			}
		})();
		if(typeof $proto.pages[pid]['bg']!='undefined' && $proto.pages[pid]['bg']!=''){
			imgO.himgs[pid]='i/'+$proto.si+'/'+$proto.pages[pid]['bg'];
		}
		if(typeof $proto.pages[pid]['elems']!='undefined'){
			for(var j in $proto.pages[pid]['elems']){
				if($proto.pages[pid]['elems'][j]['type']=='text'){continue;}
				var bg='i/'+$proto.si+'/'+j+'.png';
				if(typeof $proto.pages[pid]['elems'][j]['bg']!='undefined' && $proto.pages[pid]['elems'][j]['bg']!=''){
					bg='i/'+$proto.si+'/'+$proto.pages[pid]['elems'][j]['bg'];
				}
				imgO.himgs[j]=bg;

				if(typeof $proto.pages[pid]['elems'][j]['type']!='undefined' && $proto.pages[pid]['elems'][j]['type']=='q'){
					imgO.himgs[j+'s']=bg.replace('.png','s.png');
				}
			}
		}
		imgO.init();
	}
	,render:function (){
		for(var i in $proto.pages){
			if(!km_jc.pageresourceload[i]){continue;}
			if(km_jc.pageresourcerender[i]){continue;}
			km_jc.render_i(i);
		}		
	}
	,render_i:function (pid){
		var i=pid;
		if(typeof $proto.pages[i]['bgcolor']!='undefined' && $proto.pages[i]['bgcolor']!=''){
			$('#d_'+i).css({'background-color':$proto.pages[i].bgcolor});
		}
		var h=(typeof $proto.pages[i]['h']=='undefined' || $proto.pages[i]['h']==0)?$proto.pv.a[1]:$proto.pages[i]['h']*$proto.rad;
		if(typeof $proto.pages[i]['bg']!='undefined' && $proto.pages[i]['bg']!=''){
			$('#d_'+i+' .bg img').attr('src','i/'+$proto.si+'/'+$proto.pages[i].bg);
			$('#d_'+i+' .bg img').css({
				'width':$proto.pv.b[0]+'px'
				,'height':$proto.pv.b[1]+'px'
				,'left':$proto.pv.b[2]+'px'
				,'top':$proto.pv.b[3]+'px'
			});
		}else{
			$('#d_'+i+' .bg img').remove();
		}
		$('#d_'+i+' .page').css({'width':$proto.pv.a[0]+'px','height':h+'px'});
		if(typeof $proto.pages[i]['elems']!='undefined'){
			for(var j in $proto.pages[i]['elems']){
				$('#'+j).css({
					'width':($proto.pages[i]['elems'][j].w * $proto.rad)+'px',
					'height':($proto.pages[i]['elems'][j].h * $proto.rad)+'px',
					'left':($proto.pages[i]['elems'][j].l * $proto.rad)+'px',
					'top':($proto.pages[i]['elems'][j].t * $proto.rad)+'px'
				});
				if($proto.pages[i]['elems'][j]['type']=='text'){
					$('#'+j+' img').remove();
				}else{
					var bg='i/'+$proto.si+'/'+j+'.png';
					if(typeof $proto.pages[i]['elems'][j]['bg']!='undefined' && $proto.pages[i]['elems'][j]['bg']!=''){
						bg=$proto.pages[i]['elems'][j]['bg'];
					}
					$('#'+j+' img').attr('src',bg);
				}
			}
		}
		km_jc.pageresourcerender[i]=true;
	}
	//按loadorder加载资源
	,loadresource_t:function (fn,loader){
		km_jc.fn=(typeof fn=='undefined')?function (){}:fn;

		var imgO=new km_image();
		imgO.himgs={};
		imgO.func=loader;
		imgO.after=function (){
			for(var i in $proto.pages){
				if($proto.pages[i]['loadorder']!=km_jc.currloadorder){continue;}
				$proto.pages[i].size=imgO.size[i];
				if(typeof $proto.pages[i]['elems']!='undefined'){
					for(var j in $proto.pages[i]['elems']){
						if($proto.pages[i]['elems'][j]['type']=='text'){continue;}
						$proto.pages[i]['elems'][j].size=imgO.size[j];
					}
				}
				km_jc.pageresourceload[i]=true;
			}
			km_jc.render_t();
			km_jc.currloadorder++;
			km_jc.fn();
		}
		for(var i in $proto.pages){
			if($proto.pages[i]['loadorder']!=km_jc.currloadorder){continue;}
			if(typeof $proto.pages[i]['bg']!='undefined' && $proto.pages[i]['bg']!=''){
				imgO.himgs[i]='i/'+$proto.si+'/'+$proto.pages[i]['bg'];
				console.log('%c himgs '+i,'color:#999;');
			}
			if(typeof $proto.pages[i]['elems']!='undefined'){
				for(var j in $proto.pages[i]['elems']){
					if($proto.pages[i]['elems'][j]['type']=='text'){continue;}
					var bg='i/'+$proto.si+'/'+j+'.png';
					if(typeof $proto.pages[i]['elems'][j]['bg']!='undefined' && $proto.pages[i]['elems'][j]['bg']!=''){
						bg='i/'+$proto.si+'/'+$proto.pages[i]['elems'][j]['bg'];
					}
					imgO.himgs[j]=bg;
					console.log('%c himgs '+j,'color:#999;');

					if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='q'){
						imgO.himgs[j+'s']=bg.replace('.png','s.png');
						console.log('%c himgs '+j+'s','color:#999;');
					}
				}
			}
		}
		imgO.init();
	}
	//按loadorder渲染页面
	,render_t:function (){
		for(var i in $proto.pages){
			if($proto.pages[i]['loadorder']!=km_jc.currloadorder){continue;}
			if(typeof $proto.pages[i]['bgcolor']!='undefined' && $proto.pages[i]['bgcolor']!=''){
				$('#d_'+i).css({'background-color':$proto.pages[i].bgcolor});
			}
			var h=(typeof $proto.pages[i]['h']=='undefined' || $proto.pages[i]['h']==0)?$proto.pv.a[1]:$proto.pages[i]['h']*$proto.rad;
			if(typeof $proto.pages[i]['bg']!='undefined' && $proto.pages[i]['bg']!=''){
				$('#d_'+i+' .bg img').attr('src','i/'+$proto.si+'/'+$proto.pages[i].bg);
				$('#d_'+i+' .bg img').css({
					'width':$proto.pv.b[0]+'px'
					,'height':$proto.pv.b[1]+'px'
					,'left':$proto.pv.b[2]+'px'
					,'top':$proto.pv.b[3]+'px'
				});
			}else{
				$('#d_'+i+' .bg img').remove();
			}
			$('#d_'+i+' .page').css({'width':$proto.pv.a[0]+'px','height':h+'px'});
			if(typeof $proto.pages[i]['elems']!='undefined'){
				for(var j in $proto.pages[i]['elems']){
					$('#'+j).css({
						'width':($proto.pages[i]['elems'][j].w * $proto.rad)+'px',
						'height':($proto.pages[i]['elems'][j].h * $proto.rad)+'px',
						'left':($proto.pages[i]['elems'][j].l * $proto.rad)+'px',
						'top':($proto.pages[i]['elems'][j].t * $proto.rad)+'px'
					});
					if($proto.pages[i]['elems'][j]['type']=='text'){
						$('#'+j+' img').remove();
					}else{
						var bg='i/'+$proto.si+'/'+j+'.png';
						if(typeof $proto.pages[i]['elems'][j]['bg']!='undefined' && $proto.pages[i]['elems'][j]['bg']!=''){
							bg=$proto.pages[i]['elems'][j]['bg'];
						}
						$('#'+j+' img').attr('src',bg);
					}
				}
			}
			km_jc.pageresourcerender[i]=true;
		}
	}
	,loadblock:function (fn){
		km_jc.fn=(typeof fn=='undefined')?function (){}:fn;
		km_cmdlist['block']=new km_cl('block');
		var size=$('[data-km-isblock]').size();
		if(size==0){
			km_cmdlist['block']=null;
			try{delete km_cmdlist['block'];}catch(e){}
			km_jc.fn();
			return;
		}
		for(var i=0;i<size;i++){
			(function (){
				var _eo=$('[data-km-isblock]').eq(i);
				km_cmdlist['block'].cmdA.push({func:function (){
					km_jc.loadblockdata(_eo);
				}});
			})();
		}
		km_cmdlist['block'].cmdA.push({func:function (){
			km_cmdlist['block']=null;
			try{delete km_cmdlist['block'];}catch(e){}
			setTimeout(function (){km_jc.fn();},1);
		}});
		km_cmdlist['block'].cmdI=0;
		km_cmdlist['block'].doCmdA();
	}
	,loadblockdata:function (eo){
		var bid=eo.attr('id');
		var htm=bid;
		var url=eo.data('kmHtm');
		if(String(url)=='undefined'){url='';}
		if(url!=''){
			htm=url;
		}else{
			km_cmdlist['block'].doCmdA();
			return;
		}
		var posting=$.ajax({type:'get',url:htm,cache:false});
		posting.done(function(data){
			var filter=eo.data('kmFilter');
			if(String(filter)=='undefined'){filter='';}
			if(filter){
				km_filter[filter](bid,data,function (){
					km_cmdlist['block'].doCmdA();
				});
			}else{
				$('#'+bid).append(data);
				km_cmdlist['block'].doCmdA();
			}
		});
		posting.fail(function(data){
			console.log(data);
		});
	}
};
var km_util={
    resize:function (w1,h1,w2,h2,type){
    	//return [width,height,left,top]
        if(type=='crop'){
            //w1,h1 原图尺寸 w2,h2 容器的尺寸 iw,ih 缩放后的图片尺寸
            var iw,ih;
            if(w1/h1>=w2/h2){
                ih=h2;
                iw=(w1*h2)/h1;
                return [iw,ih,(0-(iw-w2)/2),0,h2/h1];
            }else{
                iw=w2;
                ih=(h1*w2)/w1;
                return [iw,ih,0,(0-(ih-h2)/2),w2/w1];
            }
        }else if(type=='full'){
            var iw,ih;
            if(w1<w2){
                if(h1<h2){
                    return [w1,h1,(w2-w1)/2,(h2-h1)/2,1];
                }else{
                    return [w1,h1,(w2-w1)/2,0,1];
                }
            }
            if(w1/h1>=w2/h2){
                iw=w2;
                ih=(h1*w2)/w1;
                return [iw,ih,0,(h2-ih)/2,w2/w1];
            }else{
                ih=h2;
                iw=(w1*h2)/h1;
                return [iw,ih,(w2-iw)/2,0,h2/h1];
            }
        }else if(type=='matchwidth'){
            var iw,ih;
            if(w1<w2){
                if(h1<h2){
                    return [w1,h1,(w2-w1)/2,(h2-h1)/2,1];
                }else{
                    return [w1,h1,(w2-w1)/2,0,1];
                }
            }
            iw=w2;
            ih=(h1*w2)/w1;
            return [iw,ih,0,(h2-ih)/2,w2/w1];
        }else{
            var iw,ih;
            if(w1/h1>=w2/h2){
                if(w1<w2){
                    return [w1,h1,(w2-w1)/2,(h2-h1)/2,1];
                }else{
                    iw=w2;
                    ih=(h1*w2)/w1;
                    return [iw,ih,0,(0-(ih-h2)/2),w2/w1];
                }
            }else{
                if(h1<h2){
                    return [w1,h1,(w2-w1)/2,(h2-h1)/2,1];
                }else{
                    ih=h2;
                    iw=(w1*h2)/h1;
                    return [iw,ih,(0-(iw-w2)/2),0,h2/h1];
                }
            }
        }
    }
};
function preventDoubleClick(){
	//防止连续快速点击两次
	var d=new Date().getTime();
	if(typeof window['lastclk']!='undefined'){
		if((d-window['lastclk'])<500){
			return false;
		}
	}
	window['lastclk']=d;
	return true;
}
function km_image(){
	var self=this;
	this.total=0;
	this.imgs=null;
	this.bar_width=0;
	this.size={};
	this.himgs={};
	this.himgs_status={};
	this.imgsUnload={};
	this.after=null;
	this.maxtimeby=20;//每张图片允许的最大加载时间(秒)
	this.it=200;//间隔时间(毫秒)
	this.its=100;//20*1000/200
	this.func=function (n,eo){
		$$("loadingline","style","width:"+Math.floor(parseFloat(n*eo.bar_width/eo.imgs.length))+"px");
		$$("loadingtxt","h","loading... "+Math.round(n*100/eo.imgs.length)+"%");
		/* after
		$$("loadingdef","h","");
		$$("loadingdef","style","display:'none'");
		*/
	}
	this.init=function (){
		self.load();
		if(typeof self.after!='undefined'){
			self.timer=window.setInterval(function (){
				self.show();
			},self.it);
		}
	};
	this.load=function (){
		self.imgs={};
		self.himgs_status={};
		self.imgsUnload={};
		for(var i in this.himgs){
			this.total++;
			this.himgs_status[i]=1;
			this.imgsUnload[i]=1;
			(function (){
				var _i=i;
				self.imgs[_i]=new Image();
				self.imgs[_i].onload=function (){self.onloadImg(_i)};
				self.imgs[_i].onerror=function (){self.unloadImg(_i)};
				self.imgs[_i].onabort=function (){self.unloadImg(_i)};
				self.imgs[_i].src=self.himgs[_i];
			})();
		}
		if(this.total==0){self.after(self);return;}
	};
	this.onloadImg=function (i){
		try{
			self.size[i]={w:self.imgs[i].width,h:self.imgs[i].height};
			self.imgs[i].onload=null;
			self.imgs[i].onerror=null;
			self.imgs[i].onabort=null;
			self.himgs_status[i]=1;
			self.imgsUnload[i]=1;
			//console.log('onloadImg');
		}catch(e){
		}
	};
	this.unloadImg=function (i){
		self.size[i]={w:0,h:0};
		self.imgs[i].onload=null;
		self.imgs[i].onerror=null;
		self.imgs[i].onabort=null;
		self.himgs_status[i]=0;
		self.imgsUnload[i]=0;
		console.log('unloadImg');
	};
	this.show=function (){
		var imgNum=0;
		for (var i in self.imgs){
			if ((self.imgs[i].complete)||(self.imgsUnload[i]==0)||(self.imgsUnload[i]>self.its)){
				imgNum++;
				//console.log('imgNum: '+imgNum);
			}else{
				self.imgsUnload[i]++;
			}
		}
		self.func(imgNum,self);
		if (imgNum<self.total){return;}
		imgNum=self.total;
		window.clearInterval(self.timer);
		self.imgs=null;
		self.after(self);
	}
}
function km_frm(d,id){
	var frm;
	try{
		frm=document.createElement('<iframe id="'+id+'" name="'+id+'" />');
	}catch(e){
		frm=document.createElement("iframe");
		var x_t=document.createAttribute("id");
		x_t.value=id;
		frm.attributes.setNamedItem(x_t);
	}

	if((/MSIE (6|7|8)/).test(navigator.userAgent)){
		var x_t=document.createAttribute("frameborder");
		x_t.value="0";
		frm.attributes.setNamedItem(x_t);
	}else{
		frm.frameborder='0';
	}

	frm.name=id;
	frm.scrolling='no';

	frm.setAttribute('width','100%');
	frm.setAttribute('height','100%');
	frm.setAttribute('scrolling','no');

	document.getElementById(d).appendChild(frm);
	frm.style.border='none';
	return frm;
}
function km_cl(idx){
	var self=this;
	this.idx=idx;
	this.errorhandle=null;
	this.cmdA=[];
	this.cmdI=-1;
	this.doCmdA=function (){
		if(this.cmdI==-1){return 0;}
		if(this.cmdI==this.cmdA.length){this.cmdA=[];this.cmdI=-1;return 1;}
		var _n=this.cmdI;
		this.cmdI++;
		try{
			if(typeof this.cmdA[_n].func=="function"){
				var _para=(typeof this.cmdA[_n].para=="undefined")?'':this.cmdA[_n].para;
				this.cmdA[_n].func(_para);
			}else{
				
			}
		}catch(e){
			console.log('km_cl error ('+this.idx+') >>> '+e.message+', func: '+_n);
			if(typeof this.errorhandle=='function'){
				this.errorhandle(e.message);
			}
		}
	};
}
var km_cmdlist={};
function km_ij(x_by,static_cmd,static_po,x_path,x_load){
	if(typeof window['__scriptLoad']=="undefined"){return;}

	if(typeof window['__sa']=='undefined'){
		window['__sa']=[];
		for(var si in __scriptLoad){
			window['__sa'].push(si);
		}
		window['__sa'].sort(function(a,b){return a.localeCompare(b)});
	}

	if(x_by){
		if(!x_path){x_path="";}
		var x_byA=(x_by.indexOf(",")!=-1)?x_by.split(","):[x_by];
		var x_pathA=(x_path.indexOf(",")!=-1)?x_path.split(","):[x_path];
		for(var si=0;si<x_byA.length;si++){
			if(typeof __scriptLoad[x_byA[si]]=="undefined"){
				var y_path=(typeof x_pathA[si]=="undefined")?"":x_pathA[si];
				__scriptLoad[x_byA[si]]={load:false,path:y_path};
			}
		}
	}

	var static_by="";
	for(var i=0;i<window['__sa'].length;i++){
		var si=window['__sa'][i];
		if(x_load==si){__scriptLoad[si].load=true;}
		if(!__scriptLoad[si].load){static_by=si;break;}
	}
	
	if(static_by==""){
		window['__sa']=null;
		window['__scriptLoad']=null;
		try{
			delete window['__sa'];
			delete window['__scriptLoad'];
		}catch(e){}
		if(typeof static_cmd!="function"){return;}
		static_cmd(static_po);
		return;
	}

	var script=document.createElement("script");
	script.type="text/javascript";
	if(script.readyState){//IE
		script.onreadystatechange=function(){
			if(script.readyState=="loaded"||script.readyState=="complete"){
				script.onreadystatechange=null;
				km_ij("",static_cmd,static_po,"",static_by);
			}
		};
	}else{//Others
		script.onload=function(){
			km_ij("",static_cmd,static_po,"",static_by);
		};
	}

	var f=__scriptLoad[static_by].path;
	var _v=($proto.debug)?sd():$proto.public_ver;
	f=f.replace("[v]",_v);
	script.src=f;
	document.getElementsByTagName("head")[0].appendChild(script);
}
function Alert(did){
	if(!did){did='d_Alert';}
	var self=this;
	this.did=did;
	this.html='';
	this.css=null;
	this.opts={
		autohide:false
		,before:function (done){
			done();
		}
		,after:function (){

		}
		,click:function (bid){
			if(bid=='ok'){
				self.a();
				$proto.scormbookmark=0;
			}else if(bid=='gotobookmark'){
				self.a();
				/*
				var pid = $('.section').eq($proto.scormbookmark).attr('id').replace('d_','');
				alert('pid: ' + pid + '\nloadorder: ' + $proto.pages[pid]['loadorder'] + '\npageresourceload: ' + km_jc.pageresourceload[pid] + '\nscormbookmark: ' + $proto.scormbookmark);
				if (!km_jc.pageresourceload[pid]) {
					km_jc.currloadorder = $proto.pages[pid]['loadorder'];
					km_jc.loadresource(function (){
						km_jc.render();
						$.fn.pagepiling.moveTo($proto.scormbookmark+1);
					});
				} else {
					$.fn.pagepiling.moveTo($proto.scormbookmark+1);
				}
				*/
				$.fn.pagepiling.moveTo($proto.scormbookmark+1);
			}
		}		
	}
	this.a=function (s,css,opts){
		if(!s){
			$('#'+this.did).css({display:'none'});
			return;
		}
		this.html=s;
		if(css){this.css=css;}
		if(opts){
			for(var i in opts){
				this.opts[i]=opts[i];
			}
		}
		if(this.css){
			$('#'+this.did).css(this.css);
		}

		this.opts.before(function (){
			$('#'+self.did).html(self.html);
			$('#'+self.did+' button').unbind().bind('click',function (){
				self.opts.click($(this).data('bid'));
			});
			self.opts.after();
		});
		
		if(this.opts.autohide){
			km_kb._set($('#'+this.did).get(0));
			setTimeout(function (){
				km_kb._try();
			},1500);
		}else{
			$('#'+this.did).css({display:'block'});
		}
	};
}
var _A_=new Alert();
var km_kb={
    showing:[],
    _fw:function (o,para,func){
        if(o==null){return;}
        if(typeof func=="function"){func(o,para);}
        o.style.display='block';
    },
    _set:function (o,para,func,func2,para2){try{
        this._fw(o,para,func);
        this.showing.push({o:o,para:para2,func:func2});
    }catch(_de){
        alert('km_kb._set: '+_de.message);
    }},
    _hide:function (){
        for(_k=this.showing.length-1;_k>=0;_k--){
            try{
                this.showing[_k].o.style.display='none';
                if((typeof this.showing[_k].func!="undefined")&&(this.showing[_k].func!=null)){
                    this.showing[_k].func(this.showing[_k].o,null,this.showing[_k].para,'');
                }
            }catch(_ex){}
        }
        this.showing=[];
    },
    _hideo:function (o){
        for(_k=this.showing.length-1;_k>=0;_k--){
            if(o==this.showing[_k].o){
                this.showing[_k].o.style.display='none';
                if((typeof this.showing[_k].func!="undefined")&&(this.showing[_k].func!=null)){
                    this.showing[_k].func(this.showing[_k].o,null,this.showing[_k].para,'');
                }
                this.showing[_k]=null;
                delete this.showing[_k];
                break;
            }
        }
    },
    _try:function (o){
        if(typeof window.fo=='object'){
            if(km_btn.suspend){
                km_btn.fc(window.fo,'mouseout');
                km_btn.suspend=false;
                return;
            }
        }
        if(this.showing.length==0){return false;}
        try{
            var ent=$d.evt();
            if(!o){o=$d.elem(ent);}
        }catch(eg1){}
        for(_k=this.showing.length-1;_k>=0;_k--){
            this._tryo(o,_k,o);
        }
        for(_k=0;_k<this.showing.length;_k++){
            if(this.showing[_k]!=null){return false;}
        }
        this.showing=[];
    },
    _tryo:function (_o,_s,o){
        if(this.showing[_s]==null){return false;}
        if(_o==this.showing[_s].o){return false;}
        if((_o==null)||(_o.tagName=="BODY")){
            var __o=this.showing[_s].o;
            var __para=this.showing[_s].para;
            var __c=true;
            if((typeof this.showing[_s].func!="undefined")&&(this.showing[_s].func!=null)){
                __c=this.showing[_s].func(__o,o,__para,_s);
            }
            if(__c){
                this.showing[_s].o.style.display='none';
                this.showing[_s]=null;
            }
            return false;
        }
        this._tryo(_o.parentNode,_s,o);
    }
};
function __kb(){
    km_kb._try();
}
var km_tab={
	clk:function (n,o,z,cb){
		if(!cb){cb='clsHide';} //clsHidden
		var ent=$d.evt();
		if(ent.stopPropagation){
			ent.stopPropagation();
		}else{
			ent.cancelBubble=true;
		}
		if(o){o=document.getElementById(o);}else{
			var _o=$d.elem(ent);
			if(_o.parentNode.childNodes.length>1){return;}
			o=_o.parentNode.parentNode.parentNode;
		}
		var _eo=$d.getChilds(o,"DIV",0);
		var eo=$d.getChilds(_eo,"SPAN",n);
		if((_eo==null)||(eo==null)){return;}
		if(eo.className.indexOf("_select")!=-1){return false;}

		var tobjs=$d.getChilds(_eo,"SPAN");
		for (var b=0;b<tobjs.length;b++){
			if(tobjs[b].className.indexOf("_select")!=-1){
				var tcls=tobjs[b].className.replace("_select","");
				$(tobjs[b]).attr('class',tcls);
			}
		}
		var t_cls=eo.className;
		if(t_cls.indexOf("_over")!=-1){
			t_cls=t_cls.replace("_over","");
		}
		t_cls+="_select";
		$(tobjs[n]).attr('class',t_cls);
		try{if(ent.type=="mouseover"){tobjs[n].click();}}catch(p9){alert(p9.message);}

		var _l=$d.getChilds(o,"DIV").length;
		if(z==null){z=1;}
		var _eo=$d.getChilds(o,"DIV")[_l-z];
		var tobjs0=$d.getChilds(_eo,"DIV");
		for (var b=0;b<tobjs0.length;b++){
			if((tobjs0[b].className!=cb)&&(tobjs0[b].className!="d-box-bot")){
				$(tobjs0[b]).attr('class',cb);
			}
		}
		$(tobjs0[n]).attr('class','');
	}
};
var $d={
  eval:function (str){
    eval(str);
  },
	getWin:function (frame,doc){
		if(PF_ie){return frame.contentWindow;}
		if(!doc){doc=$d.getDoc(frame);}
		if(doc.parentWindow){
			return doc.parentWindow;
		}
		if((isBrowser().indexOf("gecko")!=-1)||(isBrowser().indexOf("safari")!=-1)){
			var scriptElement=doc.createElement('script');
			scriptElement.innerHTML='document.parentWindow=window';
			var parentElement=doc.documentElement;
			parentElement.appendChild(scriptElement);
			parentElement.removeChild(scriptElement);
			return doc.parentWindow;
		}
		return doc.defaultView;
	},
	getDoc:function (frame){
		if(frame==null){return null;}
		if((isBrowser().indexOf("gecko")!=-1)||(isBrowser().indexOf("safari")!=-1)){
			doc=(frame.document || frame.contentWindow.document);
		}else{
			doc=(frame.contentDocument || frame.contentWindow.document);
		}
		return doc;
	},
	evt:function (){
		if(document.all)return window.event;
		try{
			func=$d.evt.caller;
			while(func!=null){
				var arg0=func.arguments[0];
				if(arg0){if((arg0.constructor==Event||arg0.constructor==MouseEvent)||(typeof(arg0)=="object"&&arg0.preventDefault&&arg0.stopPropagation)){return arg0;}}
				func=func.caller;
			}
		}catch(er2){return window.event;}
		return null;
	},
	elem:function (ent){
		try{return ent.srcElement||ent.target;}catch(_em){return null;}
	},
	dk:function (cmd){var ent=$d.evt();if(ent.keyCode==13){
		if(typeof cmd=="function"){cmd();}else{eval(cmd);}
	}},
	setInterval_i:function (){
		window.addEventListener('message', function(e) {
			console.log(e.data);
		},false);
		var it=1000; //1s
		var frm=document.createElement('iframe');
		frm.style.display='none';
		frm.id='timerios';
		//frm.src='data:text/html,%3C%21DOCTYPE%20html%3E%0A%3Chtml%3E%0A%3Chead%3E%0A%09%3Cmeta%20charset%3D%22utf-8%22%20%2F%3E%0A%09%3Cmeta%20http-equiv%3D%22refresh%22%20content%3D%22'+it+'%22%20id%3D%22metarefresh%22%20%2F%3E%0A%09%3Ctitle%3Ex%3C%2Ftitle%3E%0A%3C%2Fhead%3E%0A%3Cbody%3E%0A%09%3Cscript%3Etop.postMessage%28%27refresh%27%2C%20%27%2A%27%29%3B%3C%2Fscript%3E%0A%3C%2Fbody%3E%0A%3C%2Fhtml%3E';
		var f='';
		frm.src=f;

		document.body.insertBefore(frm, document.body.childNodes[0]);

		/*
		var s='';
		s+='<!doctype html>';
		s+='<html><head>';
		s+='<meta charset="utf-8">';
		s+='<meta http-equiv="refresh" content="15" id="metarefresh">';
		s+='<title>reload</title>';
		s+='</head>';
		s+='<body>';
		s+='<script>top.postMessage(\'[data]\', \'*\');</script>';
		s+='</body>';
		s+='</html>';
		*/

	},
	clearInterval_i:function (){
		if($$('timerios')){$$('timerios').parentNode.removeChild($$('timerios'));}
		//window.removeEventListener();
	},
	getChilds:function (d,tn,ni){
		if(d==null){return null;}
		if(!d.hasChildNodes()){
			if(ni!=null){return null;}
			return [];
		}
		var _list=[];
		var _li=d.childNodes;
		for(var _j=0;_j<_li.length;_j++){
			var d_i=_li[_j];
			if(tn){
				if(d_i.nodeName==tn.toUpperCase()){_list.push(d_i);}
			}else{
				if((d_i.nodeType==3)&&(d_i.nodeValue=="")){

				}else{
					_list.push(d_i);
				}
			}
		}
		if(ni!=null){
			var _lo=null;
			try{_lo=_list[ni];}catch(ne){}
			return _lo;
		}
		return _list;
	}
};
function sub_getPa(val,pa){
	if((pa==null)||(pa=="")){pa=top.location.href;}
	if(pa.indexOf(val+"=")==-1){return "";}
	var ppa1=pa.split(val+"=");
	var ppa2=(ppa1[1].indexOf('&')!=-1)?ppa1[1].split("&"):[ppa1[1]];
	return String(ppa2[0]);
}
function sub_getdate(ts,d_x){
	if((ts!=null)&&(ts!="")&&((String(ts).indexOf("-")!=-1)||(String(ts).indexOf(":")!=-1)||(String(ts).indexOf(" ")!=-1))){
		var d=new Date();
		var a=(ts.indexOf(" ")!=-1)?ts.split(" "):[ts,""];
		var b=(a[0].indexOf("-")!=-1)?a[0].split("-"):["","",""];
		var c=(a[1].indexOf(":")!=-1)?a[1].split(":"):["","",""];
		var s="";
		if((b[0]!=String(d.getFullYear()))&&(d_x!=2)){s+=b[0]+"-";}
		if((b[0]==String(d.getFullYear()))&&(d_x==3)){s+=b[0]+"-";}
		s+=b[1]+"-"+b[2];
		return s;
	}
	if((ts=="today")||(ts=="")||(ts==null)){
		var d=new Date();
	}else if(ts=="yestoday"){
		var d_s=new Date().getTime()-24*60*60*1000;
		var d=new Date(d_s);
	}else{
		var d=new Date(ts);
	}
	if(d_x==1){
		if(d.getFullYear()==new Date().getFullYear()){
			return (d.getMonth()+1)+"月"+d.getDate()+"日";
		}else{
			return d.getFullYear()+"年"+(d.getMonth()+1)+"月"+d.getDate()+"日";
		}
	}else if(d_x==2){
		if(d.getFullYear()==new Date().getFullYear()){
			return nTos(d.getMonth()+1)+"-"+nTos(d.getDate());
		}else{
			return d.getFullYear()+"-"+nTos(d.getMonth()+1)+"-"+nTos(d.getDate());
		}
	}else if(d_x==3){
		return d.getFullYear()+"年"+(d.getMonth()+1)+"月"+d.getDate()+"日";
	}else{
		return d.getFullYear()+"-"+nTos(d.getMonth()+1)+"-"+nTos(d.getDate());
	}
}
function sub_gettime(ts,n){
	if((ts=="today")||(ts=="")||(ts==null)){
		var d=new Date();
	}else if(ts=="yestoday"){
		var d_s=new Date().getTime()-24*60*60*1000;
		var d=new Date(d_s);
	}else{
		var d=new Date(ts);
	}
	if(n==2){
		return nTos(d.getHours())+":"+nTos(d.getMinutes());
	}else{
		return nTos(d.getHours())+":"+nTos(d.getMinutes())+":"+nTos(d.getSeconds());
	}
}
function sub_getDatetime(ts,d_x){
	return sub_getdate(ts,d_x)+" "+sub_gettime(ts);
}
function sTon(m){if((m=="")||(m==null)){return 0;}try{return parseFloat(m);}catch(_r){return 0;}}
function nTos(m){return (m<10)?"0"+String(m):String(m);}
function nTos2(m,b){var ss="";if(String(m).length<b){ss="0";for(i=1;i<b-String(m).length;i++){ss+="0";}}return ss+String(m);}
function sd(){return new Date().getTime().toString()+nTos2(Math.floor(Math.random()*1000),4);}
function rC(cs,ic,oc){if(cs.indexOf(ic)>-1){var cs=cs.split(ic);cs=cs.join(oc);}return cs;}
var FileAPI_support = (function(undefined) {
	return $("<input type='file'>").get(0).files!==undefined;
})();
var PF_host=window.location.href.substring(7,window.location.href.indexOf("/",7));
var PF_ie=false,PF_ie6=false,PF_ie7=false,PF_ie8=false,PF_ie9=false,PF_Trident=false;
function ck(){
	PF_ie=isBrowserSupported();
	if(isBrowser().indexOf("IE 版本:6")!=-1){PF_ie6=true;}
	if(isBrowser().indexOf("IE 版本:7")!=-1){PF_ie7=true;}
	if(isBrowser().indexOf("IE(Trident) 版本:")!=-1){PF_Trident=true;}
	try{
		var c1=isBrowserSupported(),l=location.href;
		if((l.indexOf("browserchk")>-1)||(l.indexOf("browsersupported")>-1)){var cs="BROWSER:"+isBrowser();document.getElementById("divchk").innerHTML=cs;return;}
	}catch(eb1){}
}
function cc(f){return f?"支持":"不支持";}
function isBrowserSupported(){
	var agt=navigator.userAgent.toLowerCase();
	var is_op=(agt.indexOf("opera")>-1),
		is_ie=((agt.indexOf("msie")>-1)&&document.all&&!is_op),
		is_ie5=((agt.indexOf("msie 5")>-1)&&document.all&&!is_op),
		is_mac=(agt.indexOf("mac")>-1),
		is_gk=(agt.indexOf("gecko")>-1)&&(agt.indexOf("trident")==-1),
		is_trident=(agt.indexOf("trident")>-1)&&(agt.indexOf("msie")==-1),
		is_sf=(agt.indexOf("safari")>-1);
	
	if(is_ie&&!is_op&&!is_mac){
		if(agt.indexOf("palmsource")>-1||agt.indexOf("regking")>-1||agt.indexOf("windows ce")>-1||agt.indexOf("j2me")>-1||agt.indexOf("avantgo")>-1||agt.indexOf(" stb")>-1){
			return false;
		}
		var v=GetFollowingFloat(agt,"msie ");
		if(v!=null){return (v>=5.5);}
	}
	if(is_trident){
		var v=GetFollowingFloat(agt,"rv:");
		if(v!=null){
			return true;
		}
	}
	return false;
}
var __ie_ver=10;
function isBrowser(){
	var s="";
	var agt=navigator.userAgent.toLowerCase();
	//alert(agt);
	var is_op=(agt.indexOf("opera")>-1),
		is_ie=((agt.indexOf("msie")>-1)&&document.all&&!is_op),
		is_ie5=((agt.indexOf("msie 5")>-1)&&document.all&&!is_op),
		is_mac=(agt.indexOf("mac")>-1),
		is_gk=(agt.indexOf("gecko")>-1)&&(agt.indexOf("trident")==-1),
		is_trident=(agt.indexOf("trident")>-1)&&(agt.indexOf("msie")==-1),
		is_sf=(agt.indexOf("safari")>-1);
	
	if(is_ie&&!is_op&&!is_mac){
		if(agt.indexOf("palmsource")>-1||agt.indexOf("regking")>-1||agt.indexOf("windows ce")>-1||agt.indexOf("j2me")>-1||agt.indexOf("avantgo")>-1||agt.indexOf(" stb")>-1){
			s="非windows操作系统";
		}
		var v=GetFollowingFloat(agt,"msie ");
		if(v!=null){s="IE 版本:"+v;__ie_ver=parseFloat(v);}
	}
	if(is_trident){
		var v=GetFollowingFloat(agt,"rv:");
		if(v!=null){
			s="IE 版本:"+v;
		}
	}
	if(is_gk&&!is_sf){
		var v=GetFollowingFloat(agt,"rv:");
		if(v!=null){
			s="gecko 版本:"+v;
		}else{
			v=GetFollowingFloat(agt,"galeon/");
			if(v!=null){s="gecko 版本:"+v;}
		}
	}
	if(is_sf){
		var v=GetFollowingFloat(agt,"safari/");
		if(v!=null){s="safari 版本:"+v;}
	}
	if(is_op){
		var v=GetFollowingFloat(agt,"opera ");
		if(v==null){
			v=GetFollowingFloat(agt,"opera/");
		}
		if(v!=null){s="Opera 版本:"+v;}
	}
	return s;
}
function GetFollowingFloat(str,pfx){var i=str.indexOf(pfx);if(i>-1){var v=parseFloat(str.substring(i+pfx.length));if(!isNaN(v)){return v;}}return null;}
function isCookieEnabled(){
	var s=String(new Date().getTime());
	document.cookie="cookie"+s;
	var ws_c=(document.cookie.indexOf("cookie"+s)>-1)?true:false;
	document.cookie="";
	return ws_c;
}
ck();

var mc_t5=function (did,itemcls){
	var self=this;
	this.did=did;
	this.itemcls=itemcls;
	this.n=null;
	this.x=2;
	this.max=1;/*最多做题次数 0 不限*/
	this.answer="";/*正确答案*/
	this.answer2="";/*用户选择的答案*/
	this.correct=function (){}
	this.incorrect=function (){}
	this.init=function (answer){
		this.answer=answer;
		this.n=this.answer.length;
		this.reset();
	};
	this.doclick=function (ee){
		//防止连续快速点击两次
		var d=new Date().getTime();
		if(typeof this.clk!='undefined'){if((d-this.clk)<100){return;}}
		this.clk=d;

		var c=$(ee).hasClass(self.itemcls+'_selected');
		$(ee).removeClass(self.itemcls+' '+self.itemcls+'_selected');
		$(ee).addClass((c)?self.itemcls:self.itemcls+'_selected');
		$(ee).find('img').attr('src',$(ee).find('img').attr('src').replace('s.png','.png'));
		if(!c){
			$(ee).find('img').attr('src',$(ee).find('img').attr('src').replace('.png','s.png'));
		}
		this.answer2="";
		$('#'+this.did+' .q').each(function (i){
			self.answer2+=($(this).hasClass(self.itemcls+'_selected'))?"1":"0";
		});
		if(self.answer2.indexOf('1')==-1){
			$("#"+this.did+" .submit_btn").css({display:'none'});
		}else{
			$("#"+this.did+" .submit_btn").css({display:'block'});
		}
	};
	this.docheck=function (){
		if(this.answer2==""){
			_A_.a("请选择答案",{'margin-top':'-20px','height':'20px'});
			return;
		}
		if(this.answer==this.answer2){
			this.disable();
			this.writef(1);
			this.correct();
			return;
		}
		this.max--;
		if(this.max<=0){
			this.disable();
			this.writef(0);
			this.incorrect();
			return;
		}
		this.reset();
		_A_.a("请再试一次",{'margin-top':'-20px','height':'20px'});
	};
	this.disable=function (){
		$('#'+this.did+' .'+this.itemcls+',#'+this.did+' .'+this.itemcls+'_selected').unbind();
		$("#"+this.did+" .submit_btn").unbind();
		$("#"+this.did+" .submit_btn").css({display:'none'});
	};
	this.reset=function (){
		console.log('bind');
		$('#'+this.did+' .'+this.itemcls+',#'+this.did+' .'+this.itemcls+'_selected').unbind().bind('click',function (){
			self.doclick(this);
		});
		$("#"+this.did+" .submit_btn").unbind().bind('click',function (){
			self.docheck();
		});
		$("#"+this.did+" .submit_btn").css({display:'none'});
	};
	this.writef=function (n){
		$('#'+this.did+' .q').each(function (i){
			if(self.answer.charAt(i)=="1"){
				var offset_right=20;
				if(typeof $proto.header['correct_offset_right']!='undefined'){
					offset_right=$proto.header['correct_offset_right'];
				}
				$(this).append('<div class="correct" style="width:'+($proto.rad*90)+'px;height:'+($proto.rad*90)+'px;right:'+(0-$proto.rad*90+offset_right)+'px;"><img src="../common/img/right.png"></div>');
			}
		});
		if($('#'+this.did+' .hint2').size()>0){
			if(n==1){
				$('#'+this.did+' .hint').show();
				$('#'+this.did+' .hint2').hide();
			}else{
				$('#'+this.did+' .hint').hide();
				$('#'+this.did+' .hint2').show();
			}
		}else{
			$('#'+this.did+' .hint').show();
		}
	};
};

var sc_t5=function (did,itemcls){
	var self=this;
	this.did=did;
	this.itemcls=itemcls;
	this.fA=[];
	this.n=null;
	this.max=1;/*最多做题次数 0 不限*/
	this.answer="";/*正确答案*/
	this.answer2="";/*用户选择的答案*/
	this.correct=function (){}
	this.incorrect=function (){}
	this.init=function (answer){
		this.answer=answer;
		this.n=this.answer.length;
		this.reset();
	};
	this.doclick=function (ee){
		//防止连续快速点击两次
		var d=new Date().getTime();
		if(typeof this.clk!='undefined'){if((d-this.clk)<100){return;}}
		this.clk=d;

		$('#'+this.did+' .q').each(function (i){
			$(this).removeClass(self.itemcls+' '+self.itemcls+'_selected');
			$(this).addClass(self.itemcls);
			$(this).find('img').attr('src',$(this).find('img').attr('src').replace('s.png','.png'));
		});
		$(ee).removeClass(self.itemcls+' '+self.itemcls+'_selected');
		$(ee).addClass(self.itemcls+'_selected');
		$(ee).find('img').attr('src',$(ee).find('img').attr('src').replace('.png','s.png'));

		this.answer2="";
		$('#'+this.did+' .q').each(function (i){
			var c=$(this).hasClass(self.itemcls+'_selected');
			self.answer2+=(c)?"1":"0";
		});
		if(self.answer2.indexOf('1')==-1){
			$("#"+this.did+" .submit_btn").css({display:'none'});
		}else{
			$("#"+this.did+" .submit_btn").css({display:'block'});
		}
	};
	this.docheck=function (){
		if(this.answer2==""){
			_A_.a("请选择答案",{'margin-top':'-20px','height':'20px'});
			return;
		}
		if(this.answer==this.answer2){
			this.disable();
			this.writef(1);
			this.correct();
			return;
		}
		this.max--;
		if(this.max<=0){
			this.disable();
			this.writef(0);
			this.incorrect();
			return;
		}
		this.reset();
		_A_.a("请再试一次",{'margin-top':'-20px','height':'20px'});
	};
	this.disable=function (){
		$('#'+this.did+' .'+this.itemcls+',#'+this.did+' .'+this.itemcls+'_selected').unbind();
		$("#"+this.did+" .submit_btn").unbind();
		$("#"+this.did+" .submit_btn").css({display:'none'});
	};
	this.reset=function (){
		$('#'+this.did+' .'+this.itemcls+',#'+this.did+' .'+this.itemcls+'_selected').unbind().bind('click',function (){
			self.doclick(this);
		});
		$("#"+this.did+" .submit_btn").unbind().bind('click',function (){
			self.docheck()
		});
		$("#"+this.did+" .submit_btn").css({display:'none'});
	};
	this.writef=function (n){
		$('#'+this.did+' .q').each(function (i){
			if(self.answer.charAt(i)=="1"){
				var offset_right=20;
				if(typeof $proto.header['correct_offset_right']!='undefined'){
					offset_right=$proto.header['correct_offset_right'];
				}
				$(this).append('<div class="correct" style="width:'+($proto.rad*90)+'px;height:'+($proto.rad*90)+'px;right:'+(0-$proto.rad*90+offset_right)+'px;"><img src="../common/img/right.png"></div>');
			}
		});
		if($('#'+this.did+' .hint2').size()>0){
			if(n==1){
				$('#'+this.did+' .hint').show();
				$('#'+this.did+' .hint2').hide();
			}else{
				$('#'+this.did+' .hint').hide();
				$('#'+this.did+' .hint2').show();
			}
		}else{
			$('#'+this.did+' .hint').show();
		}
	}
};

/* Copyright (c) 2010-2013 Marcus Westin */
(function(e){function o(){try{return r in e&&e[r]}catch(t){return!1}}var t={},n=e.document,r="localStorage",i="script",s;t.disabled=!1,t.set=function(e,t){},t.get=function(e){},t.remove=function(e){},t.clear=function(){},t.transact=function(e,n,r){var i=t.get(e);r==null&&(r=n,n=null),typeof i=="undefined"&&(i=n||{}),r(i),t.set(e,i)},t.getAll=function(){},t.forEach=function(){},t.serialize=function(e){return JSON.stringify(e)},t.deserialize=function(e){if(typeof e!="string")return undefined;try{return JSON.parse(e)}catch(t){return e||undefined}};if(o())s=e[r],t.set=function(e,n){return n===undefined?t.remove(e):(s.setItem(e,t.serialize(n)),n)},t.get=function(e){return t.deserialize(s.getItem(e))},t.remove=function(e){s.removeItem(e)},t.clear=function(){s.clear()},t.getAll=function(){var e={};return t.forEach(function(t,n){e[t]=n}),e},t.forEach=function(e){for(var n=0;n<s.length;n++){var r=s.key(n);e(r,t.get(r))}};else if(n.documentElement.addBehavior){var u,a;try{a=new ActiveXObject("htmlfile"),a.open(),a.write("<"+i+">document.w=window</"+i+'><iframe src="/favicon.ico"></iframe>'),a.close(),u=a.w.frames[0].document,s=u.createElement("div")}catch(f){s=n.createElement("div"),u=n.body}function l(e){return function(){var n=Array.prototype.slice.call(arguments,0);n.unshift(s),u.appendChild(s),s.addBehavior("#default#userData"),s.load(r);var i=e.apply(t,n);return u.removeChild(s),i}}var c=new RegExp("[!\"#$%&'()*+,/\\\\:;<=>?@[\\]^`{|}~]","g");function h(e){return e.replace(/^d/,"___$&").replace(c,"___")}t.set=l(function(e,n,i){return n=h(n),i===undefined?t.remove(n):(e.setAttribute(n,t.serialize(i)),e.save(r),i)}),t.get=l(function(e,n){return n=h(n),t.deserialize(e.getAttribute(n))}),t.remove=l(function(e,t){t=h(t),e.removeAttribute(t),e.save(r)}),t.clear=l(function(e){var t=e.XMLDocument.documentElement.attributes;e.load(r);for(var n=0,i;i=t[n];n++)e.removeAttribute(i.name);e.save(r)}),t.getAll=function(e){var n={};return t.forEach(function(e,t){n[e]=t}),n},t.forEach=l(function(e,n){var r=e.XMLDocument.documentElement.attributes;for(var i=0,s;s=r[i];++i)n(s.name,t.deserialize(e.getAttribute(s.name)))})}try{var p="__storejs__";t.set(p,p),t.get(p)!=p&&(t.disabled=!0),t.remove(p)}catch(f){t.disabled=!0}t.enabled=!t.disabled,typeof module!="undefined"&&module.exports&&this.module!==module?module.exports=t:typeof define=="function"&&define.amd?define(t):e.store=t})(Function("return this")())
function isLocalStorageNameSupported(){
	var testKey='test';
	try{
		store.set(testKey,'t');
		var _r=(store.get(testKey)=='t');
		//console.log(_r);
		store.remove(testKey);
		return _r;
	}catch(error){
		//console.log(error.message);
		return false;
	}
}
var __isLocalStorageNameSupported=isLocalStorageNameSupported();

(function() {
  var previousDevice, _addClass, _doc_element, _find, _handleOrientation, _hasClass, _orientation_event, _removeClass, _supports_orientation, _user_agent;

  previousDevice = window.device;

  window.device = {};

  _doc_element = window.document.documentElement;

  _user_agent = window.navigator.userAgent.toLowerCase();

  device.ios = function() {
    return device.iphone() || device.ipod() || device.ipad();
  };

  device.iphone = function() {
    return _find('iphone');
  };

  device.ipod = function() {
    return _find('ipod');
  };

  device.ipad = function() {
    return _find('ipad');
  };

  device.android = function() {
    return _find('android');
  };

  device.androidPhone = function() {
    return device.android() && _find('mobile');
  };

  device.androidTablet = function() {
    return device.android() && !_find('mobile');
  };

  device.blackberry = function() {
    return _find('blackberry') || _find('bb10') || _find('rim');
  };

  device.blackberryPhone = function() {
    return device.blackberry() && !_find('tablet');
  };

  device.blackberryTablet = function() {
    return device.blackberry() && _find('tablet');
  };

  device.windows = function() {
    return _find('windows');
  };

  device.windowsPhone = function() {
    return device.windows() && _find('phone');
  };

  device.windowsTablet = function() {
    return device.windows() && (_find('touch') && !device.windowsPhone());
  };

  device.fxos = function() {
    return (_find('(mobile;') || _find('(tablet;')) && _find('; rv:');
  };

  device.fxosPhone = function() {
    return device.fxos() && _find('mobile');
  };

  device.fxosTablet = function() {
    return device.fxos() && _find('tablet');
  };

  device.meego = function() {
    return _find('meego');
  };

  device.cordova = function() {
    return window.cordova && location.protocol === 'file:';
  };

  device.nodeWebkit = function() {
    return typeof window.process === 'object';
  };

  device.mobile = function() {
    return device.androidPhone() || device.iphone() || device.ipod() || device.windowsPhone() || device.blackberryPhone() || device.fxosPhone() || device.meego();
  };

  device.tablet = function() {
    return device.ipad() || device.androidTablet() || device.blackberryTablet() || device.windowsTablet() || device.fxosTablet();
  };

  device.desktop = function() {
    return !device.tablet() && !device.mobile();
  };

  device.portrait = function() {
    return (window.innerHeight / window.innerWidth) > 1;
  };

  device.landscape = function() {
    return (window.innerHeight / window.innerWidth) < 1;
  };

  device.noConflict = function() {
    window.device = previousDevice;
    return this;
  };

  _find = function(needle) {
    return _user_agent.indexOf(needle) !== -1;
  };

  _hasClass = function(class_name) {
    var regex;
    regex = new RegExp(class_name, 'i');
    return _doc_element.className.match(regex);
  };

  _addClass = function(class_name) {
    if (!_hasClass(class_name)) {
      return _doc_element.className += " " + class_name;
    }
  };

  _removeClass = function(class_name) {
    if (_hasClass(class_name)) {
      return _doc_element.className = _doc_element.className.replace(class_name, "");
    }
  };

  if (device.ios()) {
    if (device.ipad()) {
      _addClass("ios ipad tablet");
    } else if (device.iphone()) {
      _addClass("ios iphone mobile");
    } else if (device.ipod()) {
      _addClass("ios ipod mobile");
    }
  } else if (device.android()) {
    if (device.androidTablet()) {
      _addClass("android tablet");
    } else {
      _addClass("android mobile");
    }
  } else if (device.blackberry()) {
    if (device.blackberryTablet()) {
      _addClass("blackberry tablet");
    } else {
      _addClass("blackberry mobile");
    }
  } else if (device.windows()) {
    if (device.windowsTablet()) {
      _addClass("windows tablet");
    } else if (device.windowsPhone()) {
      _addClass("windows mobile");
    } else {
      _addClass("desktop");
    }
  } else if (device.fxos()) {
    if (device.fxosTablet()) {
      _addClass("fxos tablet");
    } else {
      _addClass("fxos mobile");
    }
  } else if (device.meego()) {
    _addClass("meego mobile");
  } else if (device.nodeWebkit()) {
    _addClass("node-webkit");
  } else {
    _addClass("desktop");
  }

  if (device.cordova()) {
    _addClass("cordova");
  }

  _handleOrientation = function() {
    if (device.landscape()) {
      _removeClass("portrait");
      return _addClass("landscape");
    } else {
      _removeClass("landscape");
      return _addClass("portrait");
    }
  };

  _supports_orientation = "onorientationchange" in window;

  _orientation_event = _supports_orientation ? "orientationchange" : "resize";

  if (window.addEventListener) {
    window.addEventListener(_orientation_event, _handleOrientation, false);
  } else if (window.attachEvent) {
    window.attachEvent(_orientation_event, _handleOrientation);
  } else {
    window[_orientation_event] = _handleOrientation;
  }

  _handleOrientation();

}).call(this);
