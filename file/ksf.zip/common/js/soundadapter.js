
var mySoundAdapter={
	inited:false
	,begin:{}
	,sounds:{}
	,hasSound:false
	,init:function (fn){
		if(typeof soundManager=='undefined'){return false;}
		try{
			for(var i in $proto.pages){
				if(typeof $proto.pages[i]['sound']=='undefined'){
					$proto.pages[i]['sound']='';continue;
				}
				var func=function (){};
				var autoLoad=false;
				var audiofile=$proto.pages[i]['sound'];
				var ad=audiofile.replace('audio/','');
				ad=ad.replace('.mp3','');
				$proto.pages[i]['sound']=ad;
				mySoundAdapter.sounds[ad]=soundManager.createSound({
					id: ad
					,url: audiofile
		    	,autoLoad: autoLoad
		    	,onload: func
				});
				this.hasSound=true;
			}
			$('[data-be-playsound]').each(function (){
				var func=function (){};
				var autoLoad=false;
				var audiofile=$(this).data('bePlaysound');
				var ad=audiofile.replace('audio/','');
				ad=ad.replace('.mp3','');
				$(this).data('bePlaysound',ad);
				mySoundAdapter.sounds[ad]=soundManager.createSound({
					id: ad
					,url: audiofile
		    	,autoLoad: autoLoad
		    	,onload: func
				});
			});
			if($proto.bgsound){
				mySoundAdapter.sounds['bg']=soundManager.createSound({
					id: 'bg'
					,url: $proto.bgsound
		    	,autoLoad: false
		    	,onload: function (){}
				});
				this.hasSound=true;
			}
			mySoundAdapter.inited=true;
			if(typeof fn!='undefined'){fn();}
			return true;
		}catch(e){
			console.log(e.message);
			return false;
		}
	}
	,loopSound:function (id) {
		if(!mySoundAdapter.inited){if(!mySoundAdapter.init()){return;}}
		if(typeof mySoundAdapter.sounds[id]=='undefined'){return;}
		try{
			(function (){
				var _id=id;
				mySoundAdapter.sounds[_id].play({
					onfinish: function() {
						mySoundAdapter.loopSound(_id);
					}
				});
			})();
		}catch(e){}
	}
	,playloop:function (id){//循环播放
		if(!mySoundAdapter.inited){if(!mySoundAdapter.init()){return;}}
		if(typeof mySoundAdapter.sounds[id]=='undefined'){return;}
		try{
			if(!mySoundAdapter.begin[id]){
				//console.log('play');
				mySoundAdapter.loopSound(id);
				mySoundAdapter.begin[id]=true;
			}else{
				//console.log('resume');
				mySoundAdapter.sounds[id].resume();
			}
		}catch(e){
			console.log(e.message);
		}
	}
	,playresume:function (id){//播放或继续
		if(!mySoundAdapter.inited){if(!mySoundAdapter.init()){return;}}
		if(typeof mySoundAdapter.sounds[id]=='undefined'){return;}
		try{
			if(!mySoundAdapter.begin[id]){
				mySoundAdapter.sounds[id].play();
				mySoundAdapter.begin[id]=true;
			}else{
				mySoundAdapter.sounds[id].resume();
			}
		}catch(e){}
	}
	,play:function (id){//始终从头播放
		if(!mySoundAdapter.inited){if(!mySoundAdapter.init()){return;}}
		if(typeof mySoundAdapter.sounds[id]=='undefined'){return;}
		try{
			if(!mySoundAdapter.begin[id]){
				mySoundAdapter.begin[id]=true;
			}
			//alert('a');
			mySoundAdapter.sounds[id].play();
		}catch(e){}
	}
	,pause:function (id){
		if(!mySoundAdapter.inited){if(!mySoundAdapter.init()){return;}}
		if(typeof mySoundAdapter.sounds[id]=='undefined'){return;}
		try{
			//console.log('pause');
			mySoundAdapter.sounds[id].pause();
		}catch(e){}
	}
	,stop:function (id){
		if(!mySoundAdapter.inited){if(!mySoundAdapter.init()){return;}}
		if(typeof mySoundAdapter.sounds[id]=='undefined'){return;}
		try{
			mySoundAdapter.sounds[id].stop();
		}catch(e){}
	}
}