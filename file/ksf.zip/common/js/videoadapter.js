
var videoAdapter={
	vp:null
	,vid:''
	,beforeEnd:null
	,doend:function (){}
	,done:function (){}

	,init_status:false
	,lastpoint:-1
	,cmdflag:{}
	,playtimes:0

	,init:function (pid,vid,opts,done){
		this.dispose();
		if(done){this.done=done;}
		this.init_status=false;
		this.lastpoint=-1;
		this.cmdflag={};
		this.playtimes=0;
		this.vid=vid;
		this.pid=pid;

		this.duration=-1;
		this.currVol=2;
		this.pausedby='';
		this.beforeEnd=null;
		this.doend=function (){}
		this.isfullscreen=false;
		this.timeby=0;//计时累计
		this.timeit=1.0;//计时间隔
		this.timere=0;//计时器

		var css='';
		css+='<style id="video-css">';
		
		css+='</style>';
		$('#video-css').remove();
		$('head').append(css);

		var s='';
		s+='<video id="'+videoAdapter.vid+'" class="vp video-js vjs-default-skin">';
		s+='</video>';
		$('#'+videoAdapter.pid+' .video-box').append(s);

		opts.controls=true;

		videoAdapter.vp=videojs(videoAdapter.vid,opts,function (){
			videoAdapter.done();
		});

		this.vp.on("timeupdate", p_timeupdate);
		this.vp.on("loadedmetadata", p_loadedmetadata);
		this.vp.on("play", p_play);
		this.vp.on("pause", p_pause);
		this.vp.on("error", p_error);
		this.vp.on("progress", p_progress);
		this.vp.on("loadstart", p_loadstart);
		this.vp.on("loadeddata", p_loadeddata);
		this.vp.on("loadedalldata", p_loadedalldata);
		this.vp.on("durationchange", p_durationchange);
	}
	,addSioEvent:function (evt,func){
		if(evt=='ended'){
			videoAdapter.beforeEnd=null;
			if(typeof func!='function'){
				p_ended=function (){
					videoAdapter.vp.pause();
					try{videoAdapter.emit('ended');}catch(ex){
						videoLog('p_ended:'+ex.message);
					}
				};
			}else{
				//p_ended=func;
			}
			videoAdapter.vp.on('ended', p_ended);
		}else if(evt=='beforeEnd'){
			videoAdapter.beforeEnd=function (){
				videoAdapter.mpause();
				videoAdapter.emit('beforeEnd');
			};
		}
	}
	,msrc:function (url){
		videoAdapter.pausedby='';
		if(url!=''){
			videoAdapter.vp.src(url);
		}else{

		}
	}
	,mplay:function (ss){
		/*
		if(!devDetect.isIPad()){
			if(!videoAdapter.clickable){return;}
		}
		*/
		if(videoAdapter.pausedby!=''){return;}
		if(typeof ss!='undefined'){
			videoAdapter.currentTime(ss);
		}

		/*
		$('#'+videoAdapter.pid+' .video-box .vmask').remove();
		var s='';
		s+='<div class="vmask-playing" onclick="videoAdapter.mpause()"></div>';
		$('#'+videoAdapter.pid+' .video-box').append(s);
		*/

		videoAdapter.vp.play();		
	}
	,mpause:function (){
		/*
		var s='';
		s+='<div class="vmask" onclick="videoAdapter.mplay()"><div class="vplay"></div></div>';
		$('#'+videoAdapter.pid+' .video-box').append(s);
		$('#'+videoAdapter.pid+' .video-box .vmask-playing').remove();
		*/

		if(videoAdapter.pausedby!=''){return;}
		videoAdapter.vp.pause();
	}
	,mcurrentTime:function (ss){
		if(videoAdapter.pausedby!=''){return;}
		videoAdapter.currentTime(ss);
	}
	,currentTime:function (ss){
		videoAdapter.vp.currentTime(ss);
	}
	,mvolume:function (){
		var vA=[0,0.5,1];
		videoAdapter.currVol++;
		if(videoAdapter.currVol==3){videoAdapter.currVol=0;}
		/*
		if($$('d_vbar_audio')){
			$$('d_vbar_audio').style.backgroundImage="url('../images/vbar-audio"+videoAdapter.currVol+".png')";
		}
		*/
		videoAdapter.vp.volume(vA[videoAdapter.currVol]);
	}
	,cplay:function (d,ss){
		if(videoAdapter.pausedby!=d){return;}
		if(typeof ss!='undefined'){
			videoAdapter.currentTime(ss);
		}
		videoAdapter.pausedby='';
		if(!videoAdapter.vp.paused()){return;}
		videoAdapter.mplay();
	}
	,cpause:function (d){
		if(!videoAdapter.vp){return;}
		if(videoAdapter.vp.paused()){return;}
		if(videoAdapter.pausedby==''){
			videoAdapter.mpause();
			videoAdapter.pausedby=d;
		}
	}
	,dispose:function (){
		if(!videoAdapter.vp){return;}
		videoAdapter.vp.dispose();
		videoAdapter.vp=null;
	}
	,mtimeupdateby:function (currtime){
		try{
			//this.timeby
			//this.duration
			if(this.playtimes==0){this.playtimes+=1;}
			if(currtime>10&&!this.init_status){
				this.init_status=true;
			}
		}catch(e){

		}
	}
	,emit:function (evt){
		switch(evt){
			case 'ended':
				videoAdapter.doend();
			break;
		}
	}
};

/* event */
var p_ended=function (){
	videoLog('>>>Video Event: ended');
};
var p_timeupdate=function (){
	if(videoAdapter.duration==-1||videoAdapter.duration==0){return;}
	var currtime=videoAdapter.vp.currentTime();
	if(typeof videoAdapter.beforeEnd=='function'){
		if(videoAdapter.duration-currtime<0.5 && videoAdapter.duration>0.5 && currtime>0.5){
			videoAdapter.vp.pause();
			videoAdapter.beforeEnd();
			return;
		}
	}
	var ti=currtime-videoAdapter.timeby*videoAdapter.timeit;
	if(Math.abs(ti)>=1){
		ti=0;
		videoAdapter.timeby=Math.floor(currtime/videoAdapter.timeit);
	}
	videoAdapter.timere+=ti;
	if(videoAdapter.timere>videoAdapter.timeit){
		videoAdapter.timere=0;
		videoAdapter.timeby++;
	}
	videoAdapter.mtimeupdateby(currtime);
};
var p_play=function (){
	try{
		if(device.ios()){
			audioAdapter.mpause();
		}else{
			audioAdapter.mmuted(3);
		}
	}catch(e){
		videoLog('audioAdapter.mmuted error: '+e.message);
	}
	videoLog('>>>Video Event: play');
};
var p_pause=function (){
	videoLog('>>>Video Event: pause');
};
var p_error=function (){
	videoLog('>>>Video Event: error');
};
var p_progress=function (){
	videoLog('>>>Video Event: progress');
};
var p_loadstart=function (){
	videoLog('>>>Video Event: loadstart');
};
var p_loadeddata=function (){
	videoLog('>>>Video Event: loadeddata');
};
var p_loadedalldata=function (){
	videoLog('>>>Video Event: loadedalldata');
};
var p_durationchange=function (){
	var x=videoAdapter.vp.duration();
	if(x==0 || x==''){return;}
	videoAdapter.duration=x;
	videoAdapter.tu=formatTime(Math.floor(videoAdapter.duration));
	videoLog('>>>Video Event: durationchange '+x);
};
var p_loadedmetadata=function (){
	videoAdapter.clickable=true;
	if(videoAdapter.playtimes>0){return;}

	var bufferedTimeRange=videoAdapter.vp.buffered();
	var numberOfRanges=bufferedTimeRange.length;// Number of different ranges of time have been buffered. Usually 1.
	var firstRangeStart=bufferedTimeRange.start(0);// Time in seconds when the first range starts. Usually 0.
	var firstRangeEnd=bufferedTimeRange.end(0);// Time in seconds when the first range ends
	var firstRangeLength=firstRangeEnd-firstRangeStart;	// Length in seconds of the first time range
	var bufferedPercent=videoAdapter.vp.bufferedPercent();

	videoLog('>>>Video Event: loadedmetadata');
	videoLog('>>>Video Buffered( firstRangeStart: '+firstRangeStart+'  firstRangeEnd: '+firstRangeEnd+' )');

	//videoAdapter.mplay();
};
var _videolog=false;
function videoLog(str){
	if(!_videolog){return;}
	console.log(str);
}
function formatTime(ss){
	var mm='00';
	if(ss<10){ss='0'+String(ss);}
	else if(ss<60&&ss>=10){ss=String(ss);}
	else if(ss>=60){
		mm=Math.floor(ss/60);
		if(mm<10){mm='0'+String(mm);}
		else if(mm<60&&mm>=10){mm=String(mm);}
		ss=ss-mm*60;
		if(ss<10){ss='0'+String(ss);}
		else if(ss<60&&ss>=10){ss=String(ss);}
	}
	return mm+':'+ss;
}