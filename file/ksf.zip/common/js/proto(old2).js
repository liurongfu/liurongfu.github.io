var $proto={
	total:0,anchors:[],adaptive:0,frm:null,animate:1,islandscape:false,curr:'',bgsound:''
	,pv:{a:[],b:[]}//pageview
	,iswx:(/micromessenger/.test(navigator.userAgent.toLowerCase()))?true:false
	,active:function (pid,idx){
		if($proto.scorminitialize){
			if(idx==1){
				if($proto.scormbookmark>0 && $proto.scormbookmark<$proto.total - 1){
					var s='<div style="padding:10px;">你要从上次退出的位置继续学习吗？</div>';
					s+='<button type="button" data-bid="ok">重新开始</button>&nbsp;';
					s+='<button type="button" data-bid="gotobookmark">继续学习</button>';
					_A_.a(s);
					return;
				}
			}
		}
		if(typeof $proto.pages[pid]['audio']!='undefined' && $proto.pages[pid]['audio']!=''){
			playSound($proto.pages[pid]['audio']);
		}
		if(typeof $proto.pages[pid]['ques']!='undefined' && $proto.pages[pid]['ques']['type']!=''){
			(function (){
				var _pid=pid;
				if($proto.pages[pid].status==0){
					$proto.pages[pid].status=1;
					if($proto.pages[pid]['ques']['type']=='m'){
						$proto.pages[pid].question=new mc_t5("question_"+pid,"qitem");
					}else if($proto.pages[pid]['ques']['type']=='s'){
						$proto.pages[pid].question=new sc_t5("question_"+pid,"qitem");
					}
					$proto.pages[pid].question.init($proto.pages[pid]['ques']['answer']);
					$proto.pages[pid].question.correct=function (){
						$proto.pages[_pid].status=2;
						//playSound($proto.pages[pid]['ques']['a1']);
						if(typeof $proto.pages[_pid]['ques']['score']!='undefined' && $proto.pages[_pid]['ques']['score']!==''){
							$proto.scormscoretemp[_pid]=$proto.pages[pid]['ques']['score'];
							$proto.reportscore();
						}
					}
					$proto.pages[pid].question.incorrect=function (){
						$proto.pages[_pid].status=2;
						//playSound($proto.pages[pid]['ques']['a2']);
						if(typeof $proto.pages[_pid]['ques']['score']!='undefined' && $proto.pages[_pid]['ques']['score']!==''){
							$proto.scormscoretemp[_pid]=0;
							$proto.reportscore();
						}
					}
				}
			})();
		}
	}
	,reportscore:function (){
		if($proto.scorminitialize){
			var s=0;
			var n=0;
			for(var i in $proto.scormscoretemp){
				s+=$proto.scormscoretemp[i];
				n++;
			}
			if(n>0){
				doLMSSetValue('cmi.core.score.raw',String(s));
				doLMSCommit();
			}
		}
	}
	,chkdirection:function (){
		if(device.mobile() && device.landscape() && !$proto.islandscape){
			$('#d_scape').show();
			$proto.islandscape=true;
		}
		if(device.portrait() && $proto.islandscape){
			$('.d-scape').hide();
			$proto.islandscape=false;
		}
	}
	,init:function (){
		if(PF_ie6 || PF_ie7){
			var r='<div style="padding:50px 0 50px 0;text-align:center;color:#222;">您的浏览器不支持本课件。</div>';
			$(document.body).html(r);
			return;
		}
		var s='<div id="d_Alert" class="alert-box"></div>';
		$(document.body).append(s);
		km_cmdlist['init']=new km_cl('init');
		km_cmdlist['init'].cmdA.push({func:function (){
			/*
			if($proto['bgcolor']){
				$('.section').css({'background-color':$proto['bgcolor']});
			}
			*/
			var w=$(document.body).width();
			var h=$(window).height();
			if(w>640||device.desktop()){
				$proto.si='lg';
				$('#d_video').css({'top':'0px'});
			}else{
				$proto.si='xs';
				var eo=$('.pagenav-2').clone();
				$('.pagenav-2').remove();
				$(document.body).append(eo);
			}
			km_cmdlist['init'].doCmdA();
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			if(!$proto['pages']){
				var posting=$.ajax({type:'get',url:'i/'+$proto.si+'/pages.html',cache:false});
				posting.done(function(data){
					if(typeof data === 'string'){data=JSON.parse(data);}
					$proto.pages=data.pages;
					$proto.menu=data.menu;
					$proto.icons=data.icons;
					$proto.layout=data.layout;
					km_cmdlist['init'].doCmdA();
				});
				posting.fail(function(data){
					console.log(data);
					if($proto.si=='xs'){
						var r='<div style="padding:50px 0 50px 0;text-align:center;color:#222;">本课件不能在移动设备中学习</div>';
					}else if($proto.si=='lg'){
						return;
					}
					$(document.body).html(r);
					return;
				});
			}else{
				console.log($proto['pages']);
				km_cmdlist['init'].doCmdA();
			}
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			for(var i in $proto.menu){
				var cls=(i==0)?' class="active"':'';
				var s='<li data-menuanchor="'+i+'"'+cls+'><a href="#'+i+'">'+$proto.menu[i].t+'</a></li>';
				$('#d_menu').append(s);
			}
			if($('#d_menu').text()==''){
				$('#d_menu').remove();
				$('.d-menu-btn').remove();
			}else{
				$('.d-menu-btn').show();
				doTap($(document.body),function (){
					showMenu(0);
				});
			}
			for(var i in $proto.pages){
				if(typeof km_jc.pageresourceload[i]=='undefined'){km_jc.pageresourceload[i]=false;}
				if(typeof km_jc.pageresourcerender[i]=='undefined'){km_jc.pageresourceload[i]=false;}
				if(typeof $proto.pages[i]['loadorder']=='undefined'){
					$proto.pages[i]['loadorder']=1;
				}else{
					$proto.pages[i]['loadorder']=parseInt($proto.pages[i]['loadorder'],10);
				}
				if(typeof $proto.pages[i]['status']=='undefined'){
					$proto.pages[i]['status']=0;
				}
				var c='',d='';
				if($proto.pages[i]['type']=='p'){
					$proto.anchors.push(i);
					$proto.total++;
					c='section';
					d='#pagepiling';
				}else if($proto.pages[i]['type']=='pop'){
					c='sec';
					d='.container-page';
				}
				var s='';
				s+='<div id="d_'+i+'" class="'+c+'">';
		    	s+='<div class="bg"><img src="../common/img/transparent.png"></div>';
		    	s+='<div class="page">';
					s+='<div class="content" ';
						if(typeof $proto.pages[i]['htm']!='undefined' && $proto.pages[i]['htm']!=''){
			    		s+='data-km-isblock data-km-htm="'+$proto.pages[i]['htm']+'" ';
						}
					s+='>';
					if(typeof $proto.pages[i]['ques']!='undefined'){
						s+='<div id="question_'+i+'" class="question-box"></div>';
						$proto.scormscoretemp[i]=0;
					}
					s+='</div>';
		    s+='</div>';
				$(d).append(s);

				if(typeof $proto.pages[i]['elems']!='undefined'){
					for(var j in $proto.pages[i]['elems']){
						if(typeof $proto.pages[i]['elems'][j]['data']=='undefined'){
							$proto.pages[i]['elems'][j]['data']=null;
						}
						var cls='pa';
		    		if($proto.pages[i]['elems'][j]['data']){
		    			cls+=' pb';
		    		}else if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='q'){
							cls='q qitem pa pb';
		    		}else if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='submit'){
							cls='submit_btn pb';
		    		}else if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='hint'){
							cls='hint pb';
		    		}else if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='hint2'){
							cls='hint2 pb';
						}
		    		var s='';
		    		s+='<div id="'+j+'" class="'+cls+'" ';
		    		s+='data-km-ani="'+$proto.pages[i]['elems'][j]['ani']+'" ';
		    		s+='data-km-ani-delay="'+$proto.pages[i]['elems'][j]['delay']+'" ';
		    		if($proto.pages[i]['elems'][j]['data']){
		    			for(var k in $proto.pages[i]['elems'][j]['data']){
		    				s+='data-be-'+k+'="'+$proto.pages[i]['elems'][j]['data'][k]+'" ';
		    			}
		    		}
		    		s+='>';
		    		s+='<img src="../common/img/transparent.png">';
		    		s+='</div>';
						if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='submit'){
							$proto.pages[i]['elems'][j]['ani']='';
							$proto.pages[i]['elems'][j]['delay']=0;
						}
						if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='hint'){
							$proto.pages[i]['elems'][j]['ani']='';
							$proto.pages[i]['elems'][j]['delay']=0;
						}
						if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && $proto.pages[i]['elems'][j]['type']=='hint2'){
							$proto.pages[i]['elems'][j]['ani']='';
							$proto.pages[i]['elems'][j]['delay']=0;
						}
						if(typeof $proto.pages[i]['elems'][j]['type']!='undefined' && ($proto.pages[i]['elems'][j]['type']=='q' || $proto.pages[i]['elems'][j]['type']=='submit' || $proto.pages[i]['elems'][j]['type']=='hint' || $proto.pages[i]['elems'][j]['type']=='hint2')){
							$('#d_'+i).find('.question-box').append(s);
						}else{
							if(typeof $proto.pages[i]['ques']!='undefined'){
								$('#d_'+i).find('.question-box').before(s);
							}else{
								$('#d_'+i).find('.content').append(s);
							}
						}
					}
				}
			}
			km_cmdlist['init'].doCmdA();
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			km_jc.loadblock(function (){
				km_cmdlist['init'].doCmdA();
			});
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			var w=$(document.body).width();
			var h=$(window).height();
			if (device.ios()) {
				h=h-64;
				alert("ios")
			}
			if($proto.si=='lg' && $proto.adaptive!=1){
				var w1=$proto.layout.w;
				var h1=$proto.layout.h;
				$proto.pv.a=km_util.resize($proto.layout.w,$proto.layout.h,w1,h1,'');
				$proto.pv.b=km_util.resize($proto.layout.w,$proto.layout.h,w1,h1,'crop');
				$proto.rad=$proto.pv.a[4];
				$('#pagepiling,.container-page,.container-vid').css({
					'position':'absolute',
					'left':'50%',
					'top':'50%',
					'margin-left':(0-w1/2)+'px',
					'margin-top':(0-h1/2+28)+'px',
					'width':$proto.layout.w+'px',
					'height':$proto.layout.h+'px'
				});
				$('#d_header').css({
					'position':'absolute',
					'left':'50%',
					'top':'50%',
					'margin-left':(0-w1/2)+'px',
					'margin-top':(0-h1/2-29)+'px',
					'width':$proto.layout.w+'px',
					'height':$proto.header[$proto.si].h+'px',
					'background-color':$proto.header.bg
				});
			}else{
				var w1=w;
				var h1=h;
				$proto.pv.a=km_util.resize($proto.layout.w,$proto.layout.h,w1,h1,'');
				$proto.pv.b=km_util.resize($proto.layout.w,$proto.layout.h,w1,h1,'crop');
				$proto.rad=$proto.pv.a[4];
				$('#d_header').css({
					'position':'absolute',
					'left':'0',
					'right':'0',
					'top':'0',
					'height':($proto.header[$proto.si].h*$proto.rad)+'px',
					'background-color':$proto.header.bg
				});
				//if($proto.iswx || !$proto.header[$proto.si].show){
				if(!$proto.header[$proto.si].show){
					$('#d_header').remove();
				}
			}
			if(typeof $proto.header['pagenav_fcolor']!='undefined'){
				$('.pagenav .t').css({color:$proto.header['pagenav_fcolor']});
			}
			$('.bg').css({'width':w1+'px','height':h1+'px','left':'0px','top':'0px'});
			km_cmdlist['init'].doCmdA();
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			if($proto.si=='lg'){
				$('.d-header .home').css({
					'width':'540px',
					'height':($proto.header[$proto.si].h * $proto.rad)+'px'
				});
				$('.d-header .sound').css({
					'width':($proto.header[$proto.si].h * $proto.rad)+'px',
					'height':($proto.header[$proto.si].h * $proto.rad)+'px'
				});
			}else{
				$('.d-header .home').css({
					'width':'270px',
					'height':($proto.header[$proto.si].h * $proto.rad)+'px'
				});
				$('.d-header .sound').css({
					'width':($proto.header[$proto.si].h * $proto.rad)+'px',
					'height':($proto.header[$proto.si].h * $proto.rad)+'px'
				});
			}
			showicon();
      $('.page').css({'visibility':'visible'});
			$('[data-be-clicktohide]').each(function (){
				$(this).css({opacity:0.9});
			});
			$('[data-be-clicktoshow]').each(function (){
				var t=$.trim($(this).data('beClicktoshow'));
				t=(t.indexOf(',')==-1)?[t]:t.split(',');
				for(var m=0;m<t.length;m++){
					//$('#'+t[m]).css({display:'none'});
					t[m]=$.trim(t[m]);
					$('#'+t[m]).removeClass('pa').addClass('pax');
				}
			});
			$('.d-header .home').bind('click',function (){
				//$.fn.pagepiling.moveTo(1);
			});
			km_cmdlist['init'].doCmdA();
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			km_jc.loadresource(function (){
				km_jc.render();
				km_cmdlist['init'].doCmdA();
			});
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			soundManager.setup({
				url: '../common/js/soundmanagerv297a/swf/soundmanager2_flash9.swf',
				flashVersion: 9,
				html5PollingInterval: 50,
				onready: function() {
					mySoundAdapter.init(function (){
						if($proto.bgsound){
							mySoundAdapter.playloop('bg');
							$('.sound').bind('click',function (){
								doSound();
							});
						}else{
							$('.sound').bind('click',function (){
								doSound2(1);
							});
						}
						if(mySoundAdapter.hasSound){
							$('.d-header .sound').show();
							$('.d-header .sound img').attr('src','sound-'+$proto.si+'.png');
						}else{
							$('.d-header .sound').hide();
						}
						km_cmdlist['init'].doCmdA();
					});
				}
			});
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
			
			bindunbeforunload(function (){
				$proto.scormfinish();
			});
			
			$proto.scorminit();
			$('#pagepiling').pagepiling({
				//anchors: $proto.anchors,
		    //menu: '#d_menu',

        direction: 'vertical',
        verticalCentered: true,
        scrollingSpeed: 700,
        easing: 'swing',
        loopBottom: false,
        loopTop: false,
        css3: true,
        navigation: false,
        normalScrollElements: null,
        normalScrollElementTouchThreshold: 5,
        touchSensitivity: 5,
        keyboardScrolling: true,
        sectionSelector: '.section',
        animateAnchor: false,
        onLeave: function(index, nextIndex, direction){
			  	var pid=$('#pagepiling .section').eq(index-1).attr('id').replace('d_','');
        	$proto.pageleave(pid, index, nextIndex, direction);
        },
        afterLoad: function(anchorLink, index){
					if($proto.scorminitialize){
						doLMSSetValue('cmi.core.lesson_location',index+'/'+$proto.total);
						doLMSCommit();
					}
			  	var pid=$('#pagepiling .section').eq(index-1).attr('id').replace('d_','');
			  	if(!km_jc.pageresourcerender[pid]){
			  		$('#d_'+pid).append('<div class="loading"><img src="../common/img/loading.gif"></div>');
		  			km_jc.currloadorder = $proto.pages[pid]['loadorder'];
			  		(function (){
			  			var _pid=pid;
			  			var _anchorLink=anchorLink;
			  			var _index=index;
							km_jc.loadresource(function (){
								km_jc.render();
								$('#d_'+pid+' .loading').remove();
								$proto.pageload(_pid, _anchorLink, _index);
							});
			  		})();
			  	}else{
			  		$proto.pageload(pid, anchorLink, index);
			  	}
        },
        afterRender: function(){
					var currentDate=new Date().getTime();
					var elapsedSeconds=((currentDate-$proto.scormstartdate)/1000);
					var formattedTime=convertTotalSeconds(elapsedSeconds);
					//doLMSSetValue('cmi.core.session_time',formattedTime);
					//doLMSCommit();
					doLMSSetValue('cmi.core.exit','suspend');
					doLMSCommit();
					$proto.scormstartdate=currentDate;

					if($proto.scorminitialize){
						doLMSSetValue('cmi.core.lesson_location','1/'+$proto.total);
						doLMSCommit();
					}
			  	var pid=$('#pagepiling .section').eq(0).attr('id').replace('d_','');
        	$proto.pageloadfirst(pid);
        	km_cmdlist['init'].doCmdA();
        }
	    });
		}});
		km_cmdlist['init'].cmdA.push({func:function (){
    	if(PF_ie8 || PF_ie9){
    		$('.pa').css({visibility:'visible'});
    	}
			$('.d-header .home img').attr('src','home-'+$proto.si+'.png');
			$('.loading').remove();
			$proto.chkdirection();
			$(window).on('resize',function (){
				$proto.chkdirection();
			});
			doBind();
			km_cmdlist['init']=null;
			try{delete km_cmdlist['init'];}catch(e){}
		}});
		km_cmdlist['init'].cmdI=0;
		km_cmdlist['init'].doCmdA();
	}
	,pageloadfirst:function (pid){
		$('.pagenav-2').hide();
		$('.pagenav').show();
		if($proto.curr && $proto.pages[$proto.curr]['sound']){
			//mySoundAdapter.pause($proto.pages[$proto.curr]['sound']);
			mySoundAdapter.stop($proto.pages[$proto.curr]['sound']);
		}
		$proto.curr=pid;
		doSound2();

  	if(PF_ie8 || PF_ie9 || $proto.animate==0){
  		$proto.active(pid,1);
			$.fn.pagepiling.setAllowScrolling(true);
	  	if(typeof $proto.actions[pid]!='undefined' && typeof $proto.actions[pid]['load']!='undefined'){
	  		$proto.actions[pid]['load']();
	  	}
  	}else{
  		(function (){
  			var _pid=pid;
				doAniBy(pid,function (){
					$proto.active(_pid,1);
					$.fn.pagepiling.setAllowScrolling(true);
			  	if(typeof $proto.actions[pid]!='undefined' && typeof $proto.actions[pid]['load']!='undefined'){
			  		$proto.actions[pid]['load']();
			  	}
				});
  		})();
		}

  	$('.pagenav .t').text('1/'+$proto.total);
	}
	,pageload:function (pid, anchorLink, index){
		//doBind();
  	$('.pagenav .t').text(index+'/'+$proto.total);
		if(typeof $proto.pages[pid]['islast']!='undefined' && $proto.pages[pid]['islast']===1){
			if($proto.scorminitialize){
				$proto.reportscore();
				doLMSSetValue('cmi.core.lesson_status','completed');
				doLMSCommit();
				//$proto.scormfinish();
			}
			//unbindunbeforunload();
		}

		if(index==1){
			$('.pagenav-2').hide();
			$('.pagenav').show();
		}else if(index==$proto.total){
			$('.pagenav-2').show();
			$('.pagenav').hide();
		}else{
			$('.pagenav-2').show();
			$('.pagenav').show();
		}
		if($proto.curr && $proto.pages[$proto.curr]['sound']){
			//mySoundAdapter.pause($proto.pages[$proto.curr]['sound']);
			mySoundAdapter.stop($proto.pages[$proto.curr]['sound']);
		}
		$proto.curr=pid;
		doSound2();

  	if(PF_ie8 || PF_ie9 || $proto.animate==0){
  		$proto.active(pid,index);
			$.fn.pagepiling.setAllowScrolling(true);
	  	if(typeof $proto.actions[pid]!='undefined' && typeof $proto.actions[pid]['load']!='undefined'){
	  		$proto.actions[pid]['load']();
	  	}
  	}else{
    	$('.pa').css({visibility:'hidden'});
    	$('.pax').css({display:'none'});
    	(function (){
    		var _index=index;
    		var _pid=pid;
				doAniBy(pid,function (){
					$proto.active(_pid,_index);
					$.fn.pagepiling.setAllowScrolling(true);
			  	if(typeof $proto.actions[pid]!='undefined' && typeof $proto.actions[pid]['load']!='undefined'){
			  		$proto.actions[pid]['load']();
			  	}
				});
    	})();
  	}

	}
	,pageleave:function (pid, index, nextIndex, direction){
  	if(typeof $proto.actions[pid]!='undefined' && typeof $proto.actions[pid]['leave']!='undefined'){
  		$proto.actions[pid]['leave'](nextIndex, direction);
  	}
  	if(!$proto.iswx){
    	$.fn.pagepiling.setAllowScrolling(false);
  	}
		if($proto.pages[pid]['sound']){
			//mySoundAdapter.pause($proto.pages[pid]['sound']);
			mySoundAdapter.stop($proto.pages[pid]['sound']);
		}
	}

	/* scorm */
	,scormstartdate:0
	,scorminitialize:false
	,scormbookmark:0
	,scormscore:0
	,scormscoretemp:{}
	,scorminit:function (){
		if(!$proto.scorminitialize){
			var result=doLMSInitialize();
			$proto.scorminitialize=(result==='true')?true:false;
		}
		if(!$proto.scorminitialize){
			return;
		}
		var status=doLMSGetValue('cmi.core.lesson_status');
		if(status==''||status=='not attempted'||status=='unknown'){
			doLMSSetValue('cmi.core.lesson_status','incomplete');
			doLMSCommit();
		}
		var loc=doLMSGetValue('cmi.core.lesson_location');
		if(loc!=''&&loc.indexOf('/')!=-1){
			var a=loc.split('/');
			$proto.scormbookmark=parseFloat(a[0])-1;
		}else{
			$proto.scormbookmark=0;
		}
		var score=doLMSGetValue('cmi.core.score.raw');
		if(score==''){
			score=0;
			doLMSSetValue('cmi.core.score.raw',String(score));
			doLMSCommit();
		}

		doLMSSetValue('cmi.core.exit','suspend');
		doLMSCommit();

		$proto.scormstartdate=new Date().getTime();
		$proto.scormscore=score;
		$proto.scormscoretemp={};
	}
	,scormfinish:function (){
		if(!$proto.scorminitialize){return false;}
		$proto.scorminitialize=false;
		var currentDate=new Date().getTime();
		var elapsedSeconds=((currentDate-$proto.scormstartdate)/1000);
		var formattedTime=convertTotalSeconds(elapsedSeconds);
		$proto.scormstartdate=currentDate;
		doLMSSetValue('cmi.core.session_time',formattedTime);
		doLMSCommit();
		doLMSFinish();
	}
};

if(navigator.userAgent.match(/iPad/i)!==null){
	document.addEventListener('touchstart',__kb,false);
}else{
	document.onmouseup=function (){
		km_kb._try();
	}
}

function doBind(){
	$('[data-be-showpage]').each(function (){
		var $btn=$(this);
		(function (){
			var v=$btn.data('beShowpage');
			$btn.unbind().bind('click',function (){
				showPage(v);
			});
		})();
	});
	$('[data-be-showvid]').each(function (){
		var $btn=$(this);
		(function (){
			var v=$btn.data('beShowvid');
			$btn.unbind().bind('click',function (){
				showVid(v);
			});
		})();
	});
	$('[data-be-playsound]').each(function (){
		var $btn=$(this);
		(function (){
			var v=$btn.data('bePlaysound');
			$btn.unbind().bind('click',function (){
				playSound(v);
			});
		})();
	});
	$('[data-be-moveto]').each(function (){
		var $btn=$(this);
		(function (){
			var v=$btn.data('beMoveto');
			$btn.unbind().bind('click',function (){
				var idx=$.inArray(v,$proto.anchors);
				$.fn.pagepiling.moveTo(idx+1);
			});
		})();
	});
	$('[data-be-clicktohide]').each(function (){
		var $btn=$(this);
		(function (){
			var _$btn=$btn;
			$btn.unbind().bind('click',function (){
				_$btn.css({visibility:'hidden'});
			});
		})();
	});
	$('[data-be-clicktoshow]').each(function (){
		var $btn=$(this);
		(function (){
			var _t=$.trim($btn.data('beClicktoshow'));
			$btn.unbind().bind('click',function (){
				var t=_t;
				t=(t.indexOf(',')==-1)?[t]:t.split(',');
				for(var m=0;m<t.length;m++){
					t[m]=$.trim(t[m]);
					if(t[m].charAt(0)=='-'){
						$('#'+t[m].substring(1)).css({display:'none'});
					}else{
						$('#'+t[m]).css({display:'block'});
					}
				}
			});
		})();
	});
}
var __sound2_on=true;
function doSound2(n){
	if(n==1){
		if(__sound2_on){
			if($proto.pages[$proto.curr]['sound']){
				//mySoundAdapter.pause($proto.pages[$proto.curr]['sound']);
				mySoundAdapter.stop($proto.pages[$proto.curr]['sound']);
			}
			__sound2_on=false;
			$('.d-header .sound img').attr('src','sound-disable-'+$proto.si+'.png');
		}else{
			if($proto.pages[$proto.curr]['sound']){
				mySoundAdapter.play($proto.pages[$proto.curr]['sound']);
			}
			__sound2_on=true;
			$('.d-header .sound img').attr('src','sound-'+$proto.si+'.png');
		}
	}else{
		if(!__sound2_on){return;}
		if($proto.pages[$proto.curr]['sound']){
			mySoundAdapter.play($proto.pages[$proto.curr]['sound']);
		}
	}
}
var __sound1_on=true;
function doSound(){
	if(__sound1_on){
		$('.d-header .sound img').attr('src','sound-disable-'+$proto.si+'.png');
		mySoundAdapter.pause('bg');
		__sound1_on=false;
	}else{
		$('.d-header .sound img').attr('src','sound-'+$proto.si+'.png');
		mySoundAdapter.playloop('bg');
		__sound1_on=true;
	}
}
function doAniBy(pid,fn){
	var a=[];
	$('#d_'+pid+' .pa').each(function (){
		var x=$(this).data('kmAni');
		var t=parseInt($(this).data('kmAniDelay'),10);
		if(x!==undefined && x!==''){
			a.push({d:$(this),x:x,t:t});
		}else{
			$(this).css({visibility:'visible'});
		}
	});
	if($proto.pages[pid].anitype=='m'){
		doAniM(a,fn);
	}else if($proto.pages[pid].anitype=='ms'){
		doAniMS(a,fn);
	}	
}
function showMenu(n){
	if(n==1){
		if(!preventDoubleClick()){return;}
		if($('#d_menu').hasClass('fadeIn')){return;}
		$('#d_menu').removeClass('animated fadeIn fadeOut');
		setTimeout(function (){
			$('#d_menu').show();
			$('#d_menu').addClass('animated fadeIn');
		},10);
	}else{
		if($('#d_menu').hasClass('fadeIn')){
			$('#d_menu').removeClass('fadeIn');
			$('#d_menu').addClass('fadeOut');
			setTimeout(function (){
				$('#d_menu').hide();
			},200);
		}
	}
}
function showVid(vid){
	$('.pagenav,.pagenav-2').hide();
	$('#d_frm_video').remove();
	$proto.frm=km_frm('d_video','d_frm_video');
	$('.container-vid').css({display:'block'});
	$.fn.pagepiling.setAllowScrolling(false);
	var src=vid;
	if(PF_ie){
		src='video-ie.html?vid='+vid;
	}else if($proto.iswx){
		src='video-wx.html?vid='+vid;
	}
	$('#pagepiling .logo').hide();
	$proto.frm.src=src;

	//暂停页面声音
	doSound();

	if($proto.pages[$proto.curr]['sound']){
		//mySoundAdapter.pause($proto.pages[$proto.curr]['sound']);
		mySoundAdapter.stop($proto.pages[$proto.curr]['sound']);
		__sound2_on=false;
		$('.d-header .sound img').attr('src','sound-disable-'+$proto.si+'.png');
	}

}
function closeVid(){
	$('.pagenav,.pagenav-2').show();
	if(PF_ie){
		$d.getWin(document.getElementById('d_frm_video')).videoAdapter.dispose();
	}
	$('#d_frm_video').remove();
	$('.container-vid').css({display:'none'});
	$.fn.pagepiling.setAllowScrolling(true);
	$('#pagepiling .logo').show();

	doSound();
	
	if($proto.pages[$proto.curr]['sound']){
		mySoundAdapter.play($proto.pages[$proto.curr]['sound']);
		__sound2_on=true;
		$('.d-header .sound img').attr('src','sound-'+$proto.si+'.png');
	}
}
function showPage(pid){
	$('.container-page .sec').css({display:'none'});
	$('#d_'+pid).css({display:'block'});
	$('.container-page').css({display:'block'});
	$.fn.pagepiling.setAllowScrolling(false);

	$('#d_'+pid+' .pa').css({
		visibility: 'visible'
	});
	/*
	doAniBy(pid,function (){

	});
	*/
}
function closePage(){
	$('.container-page .sec').css({display:'none'});
	$('.container-page').css({display:'none'});
	$.fn.pagepiling.setAllowScrolling(true);
}
function playSound(id){
	if(!id){return;}
	mySoundAdapter.play(id);
	doSound(0);
}
function showicon(){
	if(typeof $proto.icons['pagenav-2']=='undefined'){
		$('.pagenav-2').remove();
	}else{
		if($proto.si=='lg'){
			$('.pagenav-2').css({
				'width':($proto.icons['pagenav-2'].w * $proto.rad)+'px',
				'height':($proto.icons['pagenav-2'].h * $proto.rad)+'px',
				'margin-left':(0 - $proto.icons['pagenav-2'].w * $proto.rad)/2 + 'px'
			});
		}else{
			$('.pagenav-2').css({
				'width':($proto.icons['pagenav-2'].w * $proto.rad)+'px',
				'height':($proto.icons['pagenav-2'].h * $proto.rad)+'px',
				'margin-left':(0 - $proto.icons['pagenav-2'].w * $proto.rad)/2 + 'px',
				'top':($proto.header[$proto.si].h * $proto.rad)+'px'
			});
		}
		$('.pagenav-2').append('<img src="i/'+$proto.si+'/'+$proto.icons['pagenav-2'].bg+'">');
		$('.pagenav-2').bind('click',function (){
			$.fn.pagepiling.moveSectionUp();
		});
	}

	if(typeof $proto.icons['pagenav']=='undefined'){
		$('.pagenav').remove();
	}else{
		$('.pagenav').css({
			'width':($proto.icons['pagenav'].w * $proto.rad)+'px',
			'height':($proto.icons['pagenav'].h * $proto.rad)+'px',
			'margin-left':(0 - $proto.icons['pagenav'].w * $proto.rad)/2 + 'px',
		});
		$('.pagenav .t').before('<img src="i/'+$proto.si+'/'+$proto.icons['pagenav'].bg+'">');
		var z=($proto.si=='lg') ? 14 : 24 * $proto.rad;
		$('.pagenav .t').css({
			'font-size': z + 'px'
		});
		$('.pagenav').bind('click',function (){
			$.fn.pagepiling.moveSectionDown();
		});
	}
	
	if(typeof $proto.icons['close']!='undefined'){
		if($proto.si=='lg'){
			$('.close').css({
				'width':($proto.icons['close'].w * $proto.rad)+'px',
				'height':($proto.icons['close'].h * $proto.rad)+'px'
			});
		}else{
			var t=10;
			//if(!$proto.iswx && $proto.header[$proto.si].show){
			if($proto.header[$proto.si].show){
				t+=$proto.header[$proto.si].h;
			}
			$('.close').css({
				'width':($proto.icons['close'].w * $proto.rad)+'px',
				'height':($proto.icons['close'].h * $proto.rad)+'px',
				'top':(t * $proto.rad)+'px'
			});
		}
		$('.close').append('<img src="i/'+$proto.si+'/'+$proto.icons['close'].bg+'">');
	}
	
	if(typeof $proto.icons['logo']!='undefined'){
		$('.logo').css({
			'width':($proto.icons['logo'].w * $proto.rad)+'px',
			'height':($proto.icons['logo'].h * $proto.rad)+'px'
		});
		$('.logo').append('<img src="i/'+$proto.si+'/'+$proto.icons['logo'].bg+'">');
	}	
}
function bindunbeforunload(func_unload){
	window.onbeforeunload=function (){
		if(typeof func_unload=='function'){func_unload();}
		/*
		var rt='您确定要退出本课程吗？';
		if(PF_ie){
			window.event.returnValue=rt;
		}else{
			return rt;
		}
		*/
	}
}
function unbindunbeforunload(){
	window.onbeforeunload=null;
}
window.onbeforeunload=function (){
	if(PF_ie){
    $(document.body).find('object,embed,iframe').remove();
  }
};
